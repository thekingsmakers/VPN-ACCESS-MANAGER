const Setting = require('../models/Setting');
const User = require('../models/User');
const { encryptStr } = require('../utils/crypto');
const ActiveDirectory = require('activedirectory2');
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');

const normalizeBaseDn = (baseDn = '') =>
  String(baseDn)
    .split(',')
    .map(part => part.trim())
    .filter(Boolean)
    .join(',');

const normalizeAdUrl = (url = '') => {
  const raw = String(url).trim();
  if (!raw) return '';
  if (/^ldaps?:\/\//i.test(raw)) return raw;
  return `ldap://${raw}`;
};

const extractSearchCandidates = (bindUsername = '') => {
  const raw = String(bindUsername || '').trim();
  const candidates = new Set();
  if (!raw) return [];

  candidates.add(raw);

  if (raw.includes('\\')) {
    candidates.add(raw.split('\\').pop());
  }
  if (raw.includes('@')) {
    candidates.add(raw.split('@')[0]);
  }

  return Array.from(candidates).filter(Boolean);
};

const testAdConnection = (config) => {
  return new Promise((resolve, reject) => {
    try {
      const ad = new ActiveDirectory({
        url: config.url,
        baseDN: config.baseDn,
        username: config.username,
        password: config.password
      });

      const candidates = extractSearchCandidates(config.username);
      let idx = 0;

      const tryNext = () => {
        if (idx >= candidates.length) {
          return reject(new Error('AD Bind succeeded, but user lookup failed for bind identity. Verify BaseDN scope and bind username format (user@domain, DOMAIN\\user, or sAMAccountName).'));
        }

        const candidate = candidates[idx++];
        ad.findUser(candidate, (err, user) => {
          if (!err && user) return resolve(true);
          tryNext();
        });
      };

      tryNext();
    } catch(err) {
      reject(new Error('Invalid AD configuration formats.'));
    }
  });
};

const initializeOrganization = async (req, res) => {
  try {
    const settings = await Setting.findOne() || new Setting();
    if (settings.isSetupComplete) {
      return res.status(403).json({ message: "Network already completely initialized. Access violently prevented." });
    }

    const { ad, smtp, admin } = req.body;

    const adUrl = normalizeAdUrl(ad?.url || '');
    const adBaseDn = normalizeBaseDn(ad?.baseDn || '');
    const adUsername = String(ad?.username || '').trim();
    const adPassword = String(ad?.password || '');

    if (!adUrl || !adBaseDn || !adUsername || !adPassword) {
      return res.status(400).json({ message: "Incomplete Active Directory Payload" });
    }
    if (!admin?.username || !admin?.email) return res.status(400).json({ message: "Incomplete Admin Mapping" });

    // 1. Test AD Server
    try {
      await testAdConnection({
        url: adUrl,
        baseDn: adBaseDn,
        username: adUsername,
        password: adPassword
      });
    } catch (err) {
      return res.status(400).json({ message: `AD Handshake Failed: ${err.message}` });
    }

    // 2. Encrypt Credentials
    const encryptedAdPass = encryptStr(adPassword);
    const encryptedSmtpPass = smtp?.pass ? encryptStr(smtp.pass) : '';

    // 3. Update Settings Object
    settings.activeDirectory = {
      url: adUrl,
      baseDn: adBaseDn,
      username: adUsername,
      encryptedPassword: encryptedAdPass
    };

    settings.smtp = {
      host: smtp.host || 'smtp.office365.com',
      port: smtp.port || 587,
      secure: smtp.secure || false,
      user: smtp.user || '',
      encryptedPass: encryptedSmtpPass,
      requiresAuth: !!smtp.pass,
      fromAlias: smtp.fromAlias || 'VPN Portal <no-reply@domain.com>'
    };

    settings.isSetupComplete = true;
    await settings.save();

    // 4. Force inject standard skeleton admin
    await User.create({
      username: admin.username,
      email: admin.email,
      role: 'super_admin'
    });

    res.json({ message: "Organizational Telemetry Initialized.", setupState: true });

  } catch (error) {
    console.error('Setup failure:', error);
    res.status(500).json({ message: `Failed mapping Setup Hub: ${error.message}` });
  }
};

const connectDatabaseHardware = async (req, res) => {
  try {
    const { mongoUri } = req.body;
    if (!mongoUri) return res.status(400).json({ message: "Invalid MongoDB Connection Array" });
    
    // First, dynamically test the mongoose connection natively!
    await mongoose.connect(mongoUri);
    console.log("[Setup Hub] Dynamic MongoDB Handshake Successful!");
    
    // Analyze if the target database belongs to an already active infrastructure...
    const settings = await Setting.findOne();
    const isAlreadySetup = !!settings?.isSetupComplete;
    
    // Once successful, physically dump it onto the hardware
    const envPath = path.join(__dirname, '../../.env');
    let envContent = '';
    if (fs.existsSync(envPath)) {
      envContent = fs.readFileSync(envPath, 'utf8');
    }

    // Upsert MONGO_URI in .env
    const mongoLine = `MONGO_URI=${mongoUri}`;
    if (envContent.includes('MONGO_URI=')) {
      envContent = envContent.replace(/MONGO_URI=.*/g, mongoLine);
    } else {
      envContent += `\n${mongoLine}\n`;
    }
    
    fs.writeFileSync(envPath, envContent);
    
    // At this point Nodemon/PM2 usually physically restarts the runtime
    res.json({ 
      message: "Hardware DB String Mapped. The server is dynamically hooking into the instance...",
      isAlreadySetup
    });
  } catch (error) {
    console.error('MongoDB Bootstrap Error:', error.message);
    res.status(500).json({ message: `Invalid MongoDB topology: ${error.message}` });
  }
};

module.exports = {
  initializeOrganization,
  connectDatabaseHardware
};
