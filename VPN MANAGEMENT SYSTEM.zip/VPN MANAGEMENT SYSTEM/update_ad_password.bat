@echo off
echo =======================================================
echo   VPN Portal - AD Service Account Password Updater
echo =======================================================
echo.
echo Run this whenever the vpnmngr service account password
echo has been changed or reset in Active Directory.
echo.
cd /d "%~dp0backend"
node src\scripts\update_ad_password.js
echo.
pause
