@echo off
setlocal
echo ===================================================
echo VPN Portal - Manual Backend Startup
echo ===================================================
echo.
echo Use this if the automatic service (PM2) is failing.
echo Keep this window OPEN.
echo.

cd backend
echo [1/2] Verifying dependencies...
call npm install
if %errorlevel% neq 0 (
    echo [ERROR] NPM Install failed.
    pause
    exit /b
)

echo.
echo [2/2] Starting Node...
node src/server.js
if %errorlevel% neq 0 (
    echo.
    echo [FATAL ERROR] Node.js crashed with code %errorlevel%.
)

pause
