@echo off
echo ===================================================
echo VPN Portal - Frontend Production Rebuild
echo ===================================================
echo.

cd frontend
echo [1/2] Compiling assets (Vite Build)...
call npm run build

if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Build failed. Check for syntax errors.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo [2/2] Deployment Complete.
echo The new "Custom" duration feature is now live in the 'dist' folder.
echo.
echo PLEASE REFRESH YOUR BROWSER (Ctrl + F5).
pause
