@echo off
setlocal
echo ===================================================
echo VPN Portal - Project Clean ^& Reset Script
echo ===================================================
echo.
echo WARNING: This will delete node_modules in both frontend and backend.
echo It will also backup and clear your .env files.
echo.
set /p confirm="Are you sure you want to proceed? (y/n): "
if /i "%confirm%" neq "y" exit /b

echo.
echo [1/4] Backing up environment files...
if exist "backend\.env" (
    copy "backend\.env" "backend\.env.backup" >nul
    echo   - Backend .env backed up to .env.backup
)
if exist "frontend\.env" (
    copy "frontend\.env" "frontend\.env.backup" >nul
    echo   - Frontend .env backed up to .env.backup
)

echo.
echo [2/4] Cleaning Node Modules (this may take a minute)...
if exist "backend\node_modules" (
    echo   - Removing backend\node_modules...
    rmdir /s /q "backend\node_modules"
)
if exist "frontend\node_modules" (
    echo   - Removing frontend\node_modules...
    rmdir /s /q "frontend\node_modules"
)

echo.
echo [3/4] Resetting .env files to templates...
echo # Port Configuration > "backend\.env"
echo PORT=5000 >> "backend\.env"
echo MONGO_URI=mongodb://localhost:27017/vpn_management >> "backend\.env"
echo JWT_SECRET=change_this_secret >> "backend\.env"
echo AD_URL=ldap://your-ad-server.local >> "backend\.env"
echo.
echo VITE_API_URL=http://localhost:5000/api > "frontend\.env"
echo   - Environment files have been reset to default templates.

echo.
echo [4/4] Cleanup complete.
echo.
echo To restore your project, run:
echo   cd backend ^&^& npm install
echo   cd ..\frontend ^&^& npm install
echo.
pause
