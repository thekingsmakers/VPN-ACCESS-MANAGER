@echo off
echo ==========================================================
echo       VPN Access Management Portal - HARD RESTART
echo ==========================================================

echo.
echo [1/4] Terminating existing infrastructure...
taskkill /F /IM node.exe >nul 2>&1
echo - Node.js processes terminated.
taskkill /F /IM nginx.exe >nul 2>&1
echo - NGINX processes terminated.
timeout /t 2 /nobreak >nul

echo.
echo [2/4] Rebuilding Frontend Assets...
cd frontend
echo - Compiling optimized React Production Payload (This may take a minute)...
call npm run build >nul
cd ..

echo.
echo [3/4] Rebooting Backend Daemon...
echo - Spawning Express Engine on Port 5000...
start "VPN Backend API" cmd /k "cd /d ""%~dp0backend"" && node src\server.js"
echo - Waiting for backend to initialize...
timeout /t 3 /nobreak >nul

echo.
echo [4/4] Rebooting NGINX Gateway...
cd nginx-1.28.1
echo - Spinning up NGINX locally on Port 444 securely...
start "" nginx.exe
cd ..

echo.
echo ==========================================================
echo        SYSTEM SUCCESSFULLY RESTARTED AND HOSTED!
echo ==========================================================
echo NGINX is serving the Frontend natively on Port 444!
echo Node.js is handling API requests securely on Port 5000!
echo NOTE: Keep the "VPN Backend API" window OPEN.
echo.
pause
