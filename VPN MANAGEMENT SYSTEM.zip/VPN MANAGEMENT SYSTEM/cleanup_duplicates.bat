@echo off
echo ===================================================
echo VPN Portal - Active Connection Duplicate Cleanup
echo ===================================================
echo.
echo This script will revoke redundant active connections
echo and keep the one with the furthest expiry date.
echo.

node "backend\src\scripts\prune_duplicates.js"

if %ERRORLEVEL% equ 0 (
    echo.
    echo Cleanup successfully completed.
) else (
    echo.
    echo Error: Cleanup script failed. Please check the logs above.
)

pause
