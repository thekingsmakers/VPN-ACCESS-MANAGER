# VPN Access Management Portal

A secure web portal that manages VPN access through Active Directory, built with the MERN stack (MongoDB, Express, React, Node.js).

## System Requirements
- Node.js (v18+)
- MongoDB instance (local or Atlas)
- Access to an Active Directory Server (LDAPS)
- SMTP Server (Exchange / Office365)

## Setup Instructions

### 1. Backend Setup

1. Navigate to the backend directory:
   \`\`\`bash
   cd backend
   \`\`\`
2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`
3. Configure Environment Variables
   - Copy the `.env.example` file to `.env`:
   \`\`\`bash
   cp .env.example .env
   \`\`\`
   - Fill in your MongoDB connection string, Active Directory configuration, and SMTP settings.
   > **Note:** If `AD_PASSWORD` or `SMTP_PASS` are left empty while running in `NODE_ENV=development`, the system will use mocked implementations for LDAP and Email delivery to facilitate easy UI testing.
4. Start the server:
   \`\`\`bash
   npm run dev
   \`\`\`
   > The backend will start on \`http://localhost:5000\`.


### 2. Frontend Setup

1. Navigate to the frontend directory:
   \`\`\`bash
   cd frontend
   \`\`\`
2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`
3. Start the Vite development server:
   \`\`\`bash
   npm run dev
   \`\`\`
   > The frontend will start on \`http://localhost:5173\`.

### 3. Usage & Testing

1. Open your browser and navigate to \`http://localhost:5173\`.
2. Login with your mock credentials testing:
   - User: `jdoe` (password: `password`)
   - Manager: `mgr1` (password: `password`)
   - IT Admin: `admin1` (password: `password`)
3. Test the workflows:
   - Login as `jdoe`, request VPN for 14 days.
   - Login as `mgr1`, see the pending request in the queue, and approve.
   - Login as `admin1`, see the pending IT approval, and approve (this invokes the mock AD group addition and creates the access record).

## Architecture Highlights
- **Active Directory Integration**: Uses `activedirectory2` to validate credentials, fetch managers, and add/remove users from the VPN-Access group.
- **Node-Cron**: Runs every midnight to check for expiring access, revokes group membership, updates the DB, and emails the user.
- **Role-Based Access**: Custom Express Auth Guards to restrict API endpoints (`manager-approve` isolated from `it-approve`).
