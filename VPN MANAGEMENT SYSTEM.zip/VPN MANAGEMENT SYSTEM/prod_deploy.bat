@echo off
setlocal
echo ===================================================
echo VPN Portal - Full Production Deployment
echo ===================================================
echo.

:: 1. Build Frontend
echo [1/4] Building optimized frontend...
cd frontend
call npm install
call npm run build
if %errorlevel% neq 0 (
    echo Error building frontend. Aborting.
    exit /b %errorlevel%
)
cd ..

:: 2. Setup Backend Dependencies
echo [2/4] Preparing backend dependencies...
cd backend
call npm install --production
if %errorlevel% neq 0 (
    echo Error installing backend dependencies. Aborting.
    exit /b %errorlevel%
)
cd ..

:: 3. Restart Backend
echo [3/4] Starting/Restarting backend process...
echo - Terminating any existing Node.js processes...
taskkill /F /IM node.exe >nul 2>&1
timeout /t 2 /nobreak >nul
echo - Spawning Express Engine on Port 5000...
start "VPN Backend API" cmd /k "cd /d ""%~dp0backend"" && node src\server.js"
echo - Waiting for backend to initialize...
timeout /t 3 /nobreak >nul

:: 4. NGINX Reload
echo [4/4] Reloading NGINX configuration...
taskkill /F /IM nginx.exe >nul 2>&1
timeout /t 1 /nobreak >nul
cd nginx-1.28.1
start "" nginx.exe
cd ..

echo.
echo ===================================================
echo DEPLOYMENT COMPLETE
echo Access the portal at: http://localhost:444
echo NOTE: Keep the "VPN Backend API" window OPEN.
echo ===================================================
pause
