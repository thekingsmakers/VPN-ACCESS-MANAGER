@echo off
echo ==========================================================
echo       VPN Access Management Portal - ENTERPRISE BOOT
echo ==========================================================

echo.
echo [1/4] Ensuring Backend Dependencies...
cd backend
if not exist .env (
    echo - Copying default .env templates securely...
    copy .env.example .env >nul
)
if not exist node_modules (
    echo - Packaging Backend modules natively...
    call npm install >nul
)
cd ..

echo.
echo [2/4] Building Frontend Distribution Artifacts...
cd frontend
if not exist node_modules (
    echo - Packaging Frontend modules natively...
    call npm install >nul
)
echo - Compiling optimized React Production Payload (This may take a minute)...
call npm run build >nul
cd ..

echo.
echo [3/4] Spinning up Backend Node Daemon...
echo - Terminating any existing Node.js processes...
taskkill /F /IM node.exe >nul 2>&1
echo - Waiting for ports to clear...
timeout /t 2 /nobreak >nul
echo - Spawning Express Engine on Port 5000...
start "VPN Backend API" cmd /k "cd /d ""%~dp0backend"" && node src\server.js"
echo - Waiting for backend to initialize...
timeout /t 3 /nobreak >nul

echo.
echo [4/4] Deploying NGINX Reverse-Proxy Array...
cd nginx-1.28.1
taskkill /F /IM nginx.exe >nul 2>&1
echo - Spinning up NGINX locally on Port 444 securely...
start "" nginx.exe
cd ..

echo.
echo ==========================================================
echo      ENTERPRISE DEPLOYMENT SUCCESSFULLY EXECUTED!
echo ==========================================================
echo - Backend Core is natively running on Port 5000
echo - NGINX Gateway is listening perfectly on http://localhost:444
echo.
echo NOTE: Keep the "VPN Backend API" window OPEN.
echo ==========================================================
pause
