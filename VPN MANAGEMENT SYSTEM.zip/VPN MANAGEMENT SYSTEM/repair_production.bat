@echo off
setlocal
echo ===================================================
echo VPN Portal - PRODUCTION REPAIR TOOL
echo ===================================================
echo.

echo [1/4] Killing lingering processes...
taskkill /f /im nginx.exe >nul 2>&1
echo   - NGINX terminated.
taskkill /f /im node.exe >nul 2>&1
echo   - Node.js terminated.
echo   - Clearing Port 5000...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :5000') do taskkill /f /pid %%a >nul 2>&1
timeout /t 2 /nobreak >nul
echo   - Cleanup done.

echo.
echo [DIAGNOSTIC] Checking Node environment...
call node -v || (echo [FATAL] Node.js is failing to execute. Check your system paths and DLLs. && pause && exit /b)
echo   - Node OK.

echo.
echo [2/4] Verifying Frontend Build...
if not exist "frontend\dist\index.html" (
    echo [!] WARNING: Frontend build missing. Building now...
    cd frontend
    call npm run build || (echo [FATAL] NPM build failed. && pause && exit /b)
    cd ..
) else (
    echo   - Frontend build found.
)

echo.
echo [3/4] Starting Backend...
echo   - Spawning Express Engine on Port 5000...
start "VPN Backend API" cmd /k "cd /d ""%~dp0backend"" && node src\server.js"
echo   - Waiting for backend to initialize...
timeout /t 3 /nobreak >nul
echo   - Backend started.

echo.
echo [4/4] Starting NGINX...
cd nginx-1.28.1
start "" nginx.exe || (echo [FATAL] NGINX failed to start. && pause && exit /b)
cd ..
echo   - NGINX started on Port 444.

echo.
echo ===================================================
echo REPAIR COMPLETE!
echo.
echo Please try accessing: http://192.168.1.122:444
echo NOTE: Keep the "VPN Backend API" window OPEN.
echo ===================================================
pause
