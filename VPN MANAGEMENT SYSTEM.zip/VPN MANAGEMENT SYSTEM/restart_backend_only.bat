@echo off
echo ==========================================================
echo   VPN Portal - Backend-Only Restart (No Build Required)
echo ==========================================================
echo.

echo [1/3] Terminating existing Node.js processes...
taskkill /F /IM node.exe >nul 2>&1
echo Done.

echo.
echo [2/3] Waiting 2 seconds for ports to release...
timeout /t 2 /nobreak >nul

echo.
echo [3/3] Starting Backend with latest routes...
start "VPN Backend API" cmd /k "cd /d ""%~dp0backend"" && node src\server.js"

echo.
echo ==========================================================
echo Backend restarting in a new window on Port 5000.
echo NGINX continues to serve frontend on Port 444.
echo.
echo Keep the "VPN Backend API" window OPEN at all times.
echo Wait ~5 seconds, then refresh your browser.
echo ==========================================================
echo.
pause
