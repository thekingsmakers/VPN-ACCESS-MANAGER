@echo off
setlocal enabledelayedexpansion

echo ====================================================================
echo                 VPN MANAGEMENT SYSTEM - FACTORY RESET 
echo ====================================================================
echo.
echo WARNING: This script will DESTROY all existing data in the application!
echo - The MongoDB Database "vpn_management" will be permanently dropped.
echo - The Setup Wizard will be forcefully re-initialized.
echo - All locally mapped cached Node modules will be purged and redownloaded.
echo.
set /p confirm="Type 'DESTROY' exactly (without quotes) to proceed: "
if /i not "%confirm%"=="DESTROY" (
    echo System reset safely aborted. Exiting...
    pause
    exit /b
)

echo.
echo [1/4] Dropping MongoDB Database...
:: Ensures mongosh or mongo exists in PATH or executes dynamically natively.
mongo vpn_management --eval "db.dropDatabase()" 2>nul
if %ERRORLEVEL% neq 0 (
    mongosh vpn_management --eval "db.dropDatabase()" 2>nul
    if %ERRORLEVEL% neq 0 (
        echo [ERROR] MongoDB CLI not found natively in Windows PATH. Ensure MongoDB tools are installed!
    ) else (
        echo - Database physically erased gracefully.
    )
) else (
    echo - Database physically erased gracefully.
)

echo.
echo [2/4] Stripping Setup Connectivity Logic from Backend .env...
set ENV_FILE=..\backend\.env
if exist "%ENV_FILE%" (
    :: Reconstructs physical env explicitly dropping the MONGO_URI line globally!
    findstr /v /c:"MONGO_URI=" "%ENV_FILE%" > "%ENV_FILE%.tmp"
    move /y "%ENV_FILE%.tmp" "%ENV_FILE%" >nul
    echo - Hardware Mongo bounds cleanly purged natively.
) else (
    echo - Backend .env not found natively. Bypassing...
)

echo.
echo [3/4] Purging NPM Modules...
rmdir /s /q "..\backend\node_modules" 2>nul
rmdir /s /q "..\frontend\node_modules" 2>nul
echo - Packages wiped.

echo.
echo [4/4] Redownloading Factory State Modules...
cd ..\backend
call npm install
cd ..\frontend
call npm install
cd ..\scripts

echo.
echo ====================================================================
echo                    FACTORY RESET COMPLETE!
echo             Launch the app to see the Setup Wizard.
echo ====================================================================
pause
