@echo off
setlocal enabledelayedexpansion

echo ====================================================================
echo             VPN MANAGEMENT SYSTEM - DISASTER RECOVERY 
echo ====================================================================

:: Set Backup root to the standard C:\VPN_BACKUPS mapped accurately
set BACKUP_ROOT=C:\VPN_BACKUPS
set DB_NAME=vpn_management

:: Generate strict physical Timestamp layout formatting gracefully (YYYY-MM-DD_HH-MM-SS)
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set TIMESTAMP=%datetime:~0,4%-%datetime:~4,2%-%datetime:~6,2%_%datetime:~8,2%-%datetime:~10,2%-%datetime:~12,2%

set BACKUP_DIR=%BACKUP_ROOT%\%TIMESTAMP%

echo.
echo [1/3] Initializing physical disaster recovery arrays...
if not exist "%BACKUP_ROOT%" (
    mkdir "%BACKUP_ROOT%"
    echo - Created global vault securely at %BACKUP_ROOT%
)

echo [2/3] Executing mongodump schema snapshots gracefully...
:: Using standard mongodump mapped intelligently
mongodump --db=%DB_NAME% --out="%BACKUP_ROOT%" 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] MongoDB tools (mongodump) not detected statically inside system PATH mappings!
    pause
    exit /b
)

:: Rename the dumped natively generated folder sequentially securely
move /y "%BACKUP_ROOT%\%DB_NAME%" "%BACKUP_DIR%" >nul

echo [3/3] Backups physically secured natively at: %BACKUP_DIR%

echo.
echo ====================================================================
echo SUCCESS! Secure payload mappings dumped effectively.
echo To automate this nightly, simply map this script intelligently via Task Scheduler!
echo ====================================================================
pause
