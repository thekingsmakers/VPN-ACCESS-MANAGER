@echo off
setlocal enabledelayedexpansion

echo ====================================================================
echo             VPN MANAGEMENT SYSTEM - REBOOT DAEMON 
echo ====================================================================
echo.
echo This script will install a highly prioritized Windows System Task.
echo Every time the physical server restarts, it will:
echo 1. Wait strictly 30 seconds for networking to natively awaken.
echo 2. Force the MongoDB Background Service to initialize safely.
echo 3. Automatically Boot the Backend REST API seamlessly!
echo.
echo NOTE: You must run this script strictly As Administrator!
echo.
pause

set "STARTUP_BAT=%~dp0system_bootstrap.bat"

:: Dynamically physically write the Payload Automation payload string!
echo @echo off > "%STARTUP_BAT%"
echo :: VPN Bootloader File >> "%STARTUP_BAT%"
echo timeout /t 30 /nobreak >> "%STARTUP_BAT%"
echo net start MongoDB >> "%STARTUP_BAT%"
echo. >> "%STARTUP_BAT%"
echo cd /d "%~dp0..\backend" >> "%STARTUP_BAT%"
echo call npm run start =^> "%~dp0..\backend\logs\backend.log" 2^>^&1 ^& >> "%STARTUP_BAT%"
echo. >> "%STARTUP_BAT%"
echo cd /d "%~dp0..\nginx-1.28.1" >> "%STARTUP_BAT%"
echo taskkill /F /IM nginx.exe ^>nul 2^>^&1 >> "%STARTUP_BAT%"
echo start "" nginx.exe >> "%STARTUP_BAT%"

echo.
echo [1/2] Bootloader successfully constructed natively!
echo [2/2] Registering physical schtasks scheduling arrays...

schtasks /create /tn "VPN_Management_Autoboot" /tr "\"%STARTUP_BAT%\"" /sc onstart /ru SYSTEM /rl HIGHEST /f

if %ERRORLEVEL% neq 0 (
    echo.
    echo [ERROR] Encountered permission exception securely creating task mapping.
    echo Please permanently execute this exact file via "Right Click -^> Run As Administrator".
) else (
    echo.
    echo ====================================================================
    echo SUCCESS! The system is now permanently immune to host hardware reboots!
    echo ====================================================================
)
pause
