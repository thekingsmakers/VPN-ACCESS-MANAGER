const nodemailer = require('nodemailer');
const Setting = require('../models/Setting');
const AuditLog = require('../models/AuditLog');
const { decryptStr } = require('../utils/crypto');

const USE_MOCK = process.env.NODE_ENV === 'development' && !process.env.SMTP_PASS;

let cachedTransporter = null;
let lastSmtpConfigStr = '';

const getTransporter = async () => {
  if (USE_MOCK) return null;
  
  let settings = await Setting.findOne();
  let smtpConfig = settings?.smtp || {
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_PORT,
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
    from: process.env.EMAIL_FROM
  };

  const currentSmtpConfigStr = JSON.stringify(smtpConfig);

  if (!cachedTransporter || lastSmtpConfigStr !== currentSmtpConfigStr) {
    let authModule = undefined;
    if (smtpConfig.requiresAuth !== false) {
      const decryptedPass = smtpConfig.encryptedPass ? decryptStr(smtpConfig.encryptedPass) : (process.env.SMTP_PASS || '');
      if (smtpConfig.user || decryptedPass) {
        authModule = {
          user: smtpConfig.user,
          pass: decryptedPass
        };
      }
    }

    cachedTransporter = nodemailer.createTransport({
      host: smtpConfig.host,
      port: smtpConfig.port,
      secure: smtpConfig.secure || (smtpConfig.port == 465),
      ...(authModule && { auth: authModule })
    });
    lastSmtpConfigStr = currentSmtpConfigStr;
  }
  return { transporter: cachedTransporter, from: smtpConfig.from };
};

const sendEmail = async ({ to, subject, html }) => {
  if (USE_MOCK) {
    console.log(`[MOCK EMAIL] To: ${to} | Subject: ${subject}`);
    return;
  }

  try {
    const { transporter, from } = await getTransporter();
    await transporter.sendMail({
      from,
      to,
      subject,
      html
    });

    await AuditLog.create({
      category: 'SMTP',
      action: 'SMTP_SENT',
      metadata: { to, subject }
    }).catch(() => {});

  } catch (error) {
    console.error(`Email error: ${error.message}`);
    await AuditLog.create({
      category: 'SMTP',
      action: 'SMTP_FAILED',
      metadata: { to, subject, reason: error.message }
    }).catch(() => {});
  }
};

const reinitTransporter = (smtpConfig) => {
  if (USE_MOCK) return;
  
  let authModule = undefined;
  if (smtpConfig.requiresAuth !== false) {
    const decryptedPass = smtpConfig.encryptedPass ? decryptStr(smtpConfig.encryptedPass) : (process.env.SMTP_PASS || '');
    if (smtpConfig.user || decryptedPass) {
      authModule = {
        user: smtpConfig.user,
        pass: decryptedPass
      };
    }
  }

  cachedTransporter = nodemailer.createTransport({
    host: smtpConfig.host,
    port: smtpConfig.port,
    secure: smtpConfig.secure || (smtpConfig.port == 465),
    ...(authModule && { auth: authModule })
  });
  lastSmtpConfigStr = JSON.stringify(smtpConfig);
};

module.exports = {
  sendEmail,
  reinitTransporter
};
