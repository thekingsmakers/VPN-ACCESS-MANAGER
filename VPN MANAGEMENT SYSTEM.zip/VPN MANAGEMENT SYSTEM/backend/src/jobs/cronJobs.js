const cron = require('node-cron');
const AccessRecord = require('../models/AccessRecord');
const Request = require('../models/Request');
const User = require('../models/User');
const AuditLog = require('../models/AuditLog');
const ldapService = require('../services/ldapService');
const emailService = require('../services/emailService');

const initCronJobs = () => {
  // Run every 1 minute - AD Group Membership Drift Check
  // Increased frequency per user request to ensure rapid synchronization
  cron.schedule('* * * * *', async () => {
    console.log('[Drift Check] Running AD group membership reconciliation...');
    try {
      const { reconcileAdMembership } = require('../controllers/requestController');
      const stats = await reconcileAdMembership();
      console.log(`[Drift Check] Sync complete. Processed: ${stats.processed}, Revoked: ${stats.revoked}, Skipped (Safety): ${stats.skipped}, Warnings: ${stats.warnings.length}`);
    } catch (err) {
      console.error('[Drift Check] Error during AD drift reconciliation:', err);
    }
  });

  // Run every 3 minutes - Expiry Enforcement
  // Ensures users are removed from AD immediately after their window closes
  cron.schedule('*/3 * * * *', async () => {
    console.log('[Expiry Job] Checking for expired VPN records...');
    try {
      const { enforceExpiries } = require('../controllers/requestController');
      const stats = await enforceExpiries();
      if (stats.expired > 0) {
        console.log(`[Expiry Job] Enforced expiry for ${stats.expired} records.`);
      }
    } catch (err) {
      console.error('[Expiry Job] Error:', err);
    }
  });

  // Run every day at 00:00 - Daily Warning & Cleanup
  cron.schedule('0 0 * * *', async () => {
    console.log('Running daily VPN warning jobs...');
    
    // Expiry Warning Job (7 days before)
    try {
      const sevenDaysFromNow = new Date();
      sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);
      
      const startOfDay = new Date(sevenDaysFromNow.setHours(0,0,0,0));
      const endOfDay = new Date(sevenDaysFromNow.setHours(23,59,59,999));

      const warningRecords = await AccessRecord.find({
        endDate: { $gte: startOfDay, $lte: endOfDay },
        status: 'active'
      }).populate('userId');

      const Setting = require('../models/Setting');
      const settings = await Setting.findOne();
      const rawHtml = settings?.emailTemplates?.expiryWarningText || 'Your VPN access will expire in 7 days on [END_DATE]. Please submit a new request if you need to extend it.';

      for (const record of warningRecords) {
        if (!record.userId) continue;
        const customHtml = rawHtml.replace('[END_DATE]', record.endDate.toDateString());
        await emailService.sendEmail({
          to: record.userId.email,
          subject: 'VPN Access Expiring Soon',
          html: `<p>${customHtml}</p>`
        }).catch(() => {});
      }
    } catch (err) {
      console.error('Error in Daily Warning job:', err);
    }
  });
};

module.exports = initCronJobs;
