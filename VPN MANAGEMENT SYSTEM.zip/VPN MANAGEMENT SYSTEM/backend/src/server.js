console.log('--- BACKEND STARTUP INITIATED ---');
require('dotenv').config();

if (!process.env.ENCRYPTION_KEY || process.env.ENCRYPTION_KEY.length < 32) {
  console.error('\n[CRITICAL ERROR] Application Startup Halted!');
  console.error('An exact 32-character ENCRYPTION_KEY is required safely inside the .env explicitly mapping structural encryption.');
  process.exit(1);
}

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const { connectDB } = require('./config/database');
const initCronJobs = require('./jobs/cronJobs');

const authRoutes = require('./routes/authRoutes');
const requestRoutes = require('./routes/requestRoutes');
const settingRoutes = require('./routes/settingRoutes');
const setupRoutes = require('./routes/setupRoutes');
const reportRoutes = require('./routes/reportRoutes');

const app = express();

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

// Connect Database
connectDB();

// Init Cron Jobs
initCronJobs();

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/requests', requestRoutes);
app.use('/api/settings', settingRoutes);
app.use('/api/setup', setupRoutes);
app.use('/api/reports', reportRoutes);

app.get('/', (req, res) => {
  res.send('VPN Access Portal API is running...');
});

const PORT = process.env.PORT || 5000;
// Force 127.0.0.1 (IPv4) to match NGINX upstream config
app.listen(PORT, '127.0.0.1', () => {
  console.log(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`);
  console.log(`Bound to IPv4: 127.0.0.1`);
});
