const express = require('express');
const router = express.Router();
const { initializeOrganization, connectDatabaseHardware } = require('../controllers/setupController');

router.post('/initialize', initializeOrganization);
router.post('/database', connectDatabaseHardware);

module.exports = router;
