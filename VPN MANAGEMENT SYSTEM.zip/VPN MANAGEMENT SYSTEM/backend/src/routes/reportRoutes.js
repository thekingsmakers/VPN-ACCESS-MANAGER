const express = require('express');
const router = express.Router();
const reportController = require('../controllers/reportController');
const { protect, adminOnly } = require('../middlewares/authMiddleware');

router.get('/detailed', protect, adminOnly, reportController.getDetailedReport);
router.get('/stats', protect, adminOnly, reportController.getSummaryStats);

module.exports = router;
