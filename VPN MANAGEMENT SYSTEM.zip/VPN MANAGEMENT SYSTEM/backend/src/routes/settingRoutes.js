const express = require('express');
const router = express.Router();
const { getSettings, getPublicSettings, updateSettings } = require('../controllers/settingController');
const { protect, restrictTo } = require('../middlewares/authMiddleware');

router.get('/public', getPublicSettings);

router.use(protect);
router.use(restrictTo('super_admin'));

router.get('/', getSettings);
router.put('/', updateSettings);

module.exports = router;
