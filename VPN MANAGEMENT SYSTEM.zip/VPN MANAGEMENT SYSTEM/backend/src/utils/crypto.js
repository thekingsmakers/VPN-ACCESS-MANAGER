const crypto = require('crypto');

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || ''; // Must be 32 bytes
const ALGORITHM = 'aes-256-gcm';

/**
 * Encrypts a string natively.
 * @param {string} text 
 * @returns {string} iv:authTag:encryptedData format
 */
const encryptStr = (text) => {
  if (!text) return text;
  if (!ENCRYPTION_KEY || ENCRYPTION_KEY.length < 32) throw new Error('System halted: Critical ENCRYPTION_KEY failure.');
  
  const iv = crypto.randomBytes(16);
  const key = Buffer.from(ENCRYPTION_KEY.slice(0, 32), 'utf-8');
  
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  const authTag = cipher.getAuthTag().toString('hex');
  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
};

/**
 * Decrypts a generated payload string natively.
 * @param {string} text 
 * @returns {string}
 */
const decryptStr = (text) => {
  if (!text) return text;
  if (!ENCRYPTION_KEY || ENCRYPTION_KEY.length < 32) throw new Error('System halted: Critical ENCRYPTION_KEY failure.');
  
  try {
    const textParts = text.split(':');
    if (textParts.length !== 3) return text; // Possibly unencrypted string fallback during migration

    const iv = Buffer.from(textParts[0], 'hex');
    const authTag = Buffer.from(textParts[1], 'hex');
    const encryptedText = Buffer.from(textParts[2], 'hex');
    const key = Buffer.from(ENCRYPTION_KEY.slice(0, 32), 'utf-8');
    
    const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (err) {
    console.error('Crypto error mapping decryption cycle:', err.message);
    return null;
  }
};

module.exports = {
  encryptStr,
  decryptStr
};
