const mongoose = require('mongoose');

const auditLogSchema = new mongoose.Schema({
  category: {
    type: String,
    enum: ['System', 'Application', 'Security', 'SMTP', 'Logins', 'VPN Provisioning', 'Other'],
    default: 'Other'
  },
  action: {
    type: String,
    required: true
  },
  performedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: false
  },
  metadata: {
    type: mongoose.Schema.Types.Mixed
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('AuditLog', auditLogSchema);
