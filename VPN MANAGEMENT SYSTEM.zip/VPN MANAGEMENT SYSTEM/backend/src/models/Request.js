const mongoose = require('mongoose');

const requestSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  durationDays: {
    type: Number,
    required: true
  },
  justification: {
    type: String
  },
  status: {
    type: String,
    enum: ['pending_manager', 'pending_security', 'pending_it', 'approved', 'rejected'],
    default: 'pending_manager'
  },
  managerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  securityAdminId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  itAdminId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Request', requestSchema);
