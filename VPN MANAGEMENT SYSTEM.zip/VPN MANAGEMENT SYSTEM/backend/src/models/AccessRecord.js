const mongoose = require('mongoose');

const accessRecordSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  requestId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Request'
  },
  groupName: {
    type: String,
    required: true,
    default: 'VPN-Access'
  },
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    enum: ['active', 'expired', 'revoked'],
    default: 'active'
  },
  removalReason: {
    type: String,
    enum: ['expired', 'manually_revoked', 'ad_group_removed', null],
    default: null
  },
  adRemovalAlertDismissed: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true
});

accessRecordSchema.index(
  { userId: 1, status: 1 }, 
  { unique: true, partialFilterExpression: { status: 'active' } }
);

module.exports = mongoose.model('AccessRecord', accessRecordSchema);
