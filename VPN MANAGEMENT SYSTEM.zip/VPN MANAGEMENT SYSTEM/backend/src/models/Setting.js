const mongoose = require('mongoose');

const settingSchema = new mongoose.Schema({
  isSetupComplete: { type: Boolean, default: false },
  activeDirectory: {
    url: { type: String, default: '' },
    baseDn: { type: String, default: '' },
    username: { type: String, default: '' },
    encryptedPassword: { type: String, default: '' }
  },
  smtp: {
    host: { type: String, default: 'smtp.office365.com' },
    port: { type: Number, default: 587 },
    secure: { type: Boolean, default: false },
    requiresAuth: { type: Boolean, default: true },
    user: { type: String, default: '' },
    encryptedPass: { type: String, default: '' },
    fromAlias: { type: String, default: 'VPN Portal <no-reply@domain.com>' }
  },
  emailTemplates: {
    approvalText: { type: String, default: 'Your VPN access has been approved and provisioned until [END_DATE].' },
    rejectionText: { type: String, default: 'Your VPN access request was rejected.' },
    extensionText: { type: String, default: 'Your VPN secure tunnel has been extended until [END_DATE].' },
    revokeText: { type: String, default: 'Your VPN secure tunnel has been manually revoked by IT Administration.' },
    expiryWarningText: { type: String, default: 'Your VPN access will expire in 7 days on [END_DATE]. Please submit a new request if you need to extend it.' }
  },
  workflow: {
    requireManagerApproval: { type: Boolean, default: true },
    requireSecurityApproval: { type: Boolean, default: true },
    requireITAdminApproval: { type: Boolean, default: true },
    autoApproveExtensions: { type: Boolean, default: true },
    maxAutoExtensionDays: { type: Number, default: 3 },
    disableUserRequests: { type: Boolean, default: false },
    disableManagerPortal: { type: Boolean, default: false },
    disableSecurityPortal: { type: Boolean, default: false },
    disableAdminPortal: { type: Boolean, default: false }
  },
  adMapping: {
    itAdminGroup: { type: String, default: 'ITADMINTEAM' },
    itSecurityGroup: { type: String, default: 'ITSECURITYTEAM' },
    defaultVpnGroup: { type: String, default: 'VPN_USERS' }
  },
  branding: {
    portalName: { type: String, default: 'VPN Access Portal' },
    primaryColor: { type: String, default: '#2563eb' },
    secondaryColor: { type: String, default: '#4f46e5' },
    backgroundColor: { type: String, default: '#f8fafc' },
    logoBase64: { type: String, default: '' },
    logoUrl: { type: String, default: '' },
    loginBackgroundBase64: { type: String, default: '' },
    loginBackgroundUrl: { type: String, default: '' }
  },
  announcement: {
    message: { type: String, default: '' },
    expiresAt: { type: Date, default: null }
  },
  vpnDurations: [{
    days: { type: Number, required: true },
    label: { type: String, required: true }
  }]
}, {
  timestamps: true
});

module.exports = mongoose.model('Setting', settingSchema);
