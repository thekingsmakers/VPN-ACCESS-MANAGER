const Setting = require('../models/Setting');
const emailService = require('../services/emailService');
const AuditLog = require('../models/AuditLog');
const { getDbState } = require('../config/database');

const getDefaultSettings = () => ({
  smtp: {
    host: process.env.SMTP_HOST || '',
    port: process.env.SMTP_PORT || 587,
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || '',
    fromAlias: process.env.SMTP_FROM || 'VPN Portal <no-reply@tkm.local>'
  },
  adMapping: {
    itAdminGroup: 'ITADMINTEAM',
    itSecurityGroup: 'ITSECURITYTEAM',
    defaultVpnGroup: process.env.VPN_AD_GROUP || 'VPN_USERS'
  },
  workflow: {
    requireManagerApproval: true,
    requireSecurityApproval: true
  },
  branding: {
    portalName: 'VPN Access Portal',
    primaryColor: '#4f46e5',
    logoUrl: ''
  },
  vpnDurations: [
    { days: 0.000694, label: '1 Minute (Testing)' },
    { days: 7, label: '7 Days' },
    { days: 14, label: '14 Days' },
    { days: 30, label: '30 Days' }
  ]
});

const getSettings = async (req, res) => {
  try {
    let settings = await Setting.findOne();
    if (!settings) {
      settings = await Setting.create(getDefaultSettings());
    }
    res.json(settings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getPublicSettings = async (req, res) => {
  try {
    if (!getDbState()) {
      return res.json({
        isMongoConnected: false,
        isSetupComplete: false
      });
    }

    let settings = await Setting.findOne();
    if (!settings) {
      settings = await Setting.create(getDefaultSettings());
    }
    res.json({
      branding: settings.branding,
      vpnDurations: settings.vpnDurations,
      workflow: settings.workflow,
      announcement: settings.announcement,
      isSetupComplete: settings.isSetupComplete,
      isMongoConnected: true
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const updateSettings = async (req, res) => {
  try {
    let settings = await Setting.findOne();
    if (!settings) {
      settings = new Setting();
    }
    
    settings.smtp = req.body.smtp || settings.smtp;
    settings.adMapping = req.body.adMapping || settings.adMapping;
    settings.branding = req.body.branding || settings.branding;
    settings.workflow = req.body.workflow || settings.workflow;
    settings.emailTemplates = req.body.emailTemplates || settings.emailTemplates;
    
    if (req.body.announcement !== undefined) {
      settings.announcement = req.body.announcement;
    }
    
    if (req.body.vpnDurations) {
      settings.vpnDurations = req.body.vpnDurations;
    }

    await settings.save();
    
    // Notify email service of update
    if (emailService.reinitTransporter) {
       emailService.reinitTransporter(settings.smtp);
    }
    res.json(settings);

    await AuditLog.create({
      category: 'System',
      action: 'SETTINGS_MODIFIED',
      performedBy: req.user._id,
      metadata: { itemsUpdated: Object.keys(req.body) }
    }).catch(() => {});

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getSettings,
  getPublicSettings,
  updateSettings,
  getDefaultSettings,
};
