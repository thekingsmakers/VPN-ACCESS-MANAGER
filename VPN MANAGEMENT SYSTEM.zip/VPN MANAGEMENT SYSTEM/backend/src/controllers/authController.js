const jwt = require('jsonwebtoken');
const User = require('../models/User');
const AuditLog = require('../models/AuditLog');
const ldapService = require('../services/ldapService');

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });
};

const login = async (req, res) => {
  const { username, password } = req.body;

  try {
    // Authenticate with AD
    const adUser = await ldapService.authenticate(username, password);

    // Sync user to local DB using the strict AD account name, ignoring original input aliases
    let user = await User.findOne({ username: adUser.sAMAccountName });
    
    // Check if manager exists and sync if possible
    let managerId = null;
    if (adUser.manager) {
      try {
        const adManager = await ldapService.getManagerDetails(adUser.manager);
        let managerInfo = await User.findOne({ username: adManager.sAMAccountName });
        if (!managerInfo) {
          try {
            managerInfo = await User.create({
              username: adManager.sAMAccountName,
              email: adManager.mail,
              fullName: adManager.displayName,
              role: 'manager' // Assume manager role by default for managers
            });
          } catch (err) {
            if (err.code === 11000) {
              managerInfo = await User.findOne({ username: adManager.sAMAccountName });
            } else {
              throw err;
            }
          }
        }
        managerId = managerInfo._id;
      } catch (err) {
        console.error('Failed to sync manager:', err.message);
      }
    }

    if (!user) {
      try {
        user = await User.create({
          username: adUser.sAMAccountName,
          email: adUser.mail,
          fullName: adUser.displayName,
          role: adUser.role || 'user', // Default to user unless overridden by mock
          managerId,
          adDn: adUser.dn
        });
      } catch (err) {
        if (err.code === 11000) {
          user = await User.findOne({ username: adUser.sAMAccountName });
          // In the event of a race condition catch, ensure we forcefully push the role from AD 
          user.role = adUser.role || 'user';
          await user.save();
        } else {
          throw err;
        }
      }
    } else {
      // Update info
      user.email = adUser.mail;
      user.fullName = adUser.displayName;
      user.role = adUser.role || 'user';
      if (managerId) user.managerId = managerId;
      await user.save();
    }

    const settings = await require('../models/Setting').findOne();
    const wf = settings?.workflow;
    
    if (wf) {
      if (user.role === 'user' && wf.disableUserRequests) {
        return res.status(403).json({ message: "End-user access is currently disabled natively by IT Administration." });
      }
      if (user.role === 'manager' && wf.disableManagerPortal) {
        return res.status(403).json({ message: "Manager portal access is currently disabled natively by IT." });
      }
      if (user.role === 'it_admin' && wf.disableSecurityPortal) {
        return res.status(403).json({ message: "IT Security portal access is currently disabled natively." });
      }
      if (['it_admin'].includes(user.role) && wf.disableAdminPortal) {
        return res.status(403).json({ message: "General Administrative portal access is currently disabled natively." });
      }
    }

    res.json({
      _id: user._id,
      username: user.username,
      email: user.email,
      role: user.role,
      token: generateToken(user._id),
    });
    
    await AuditLog.create({
      category: 'Logins',
      action: 'LOGIN_SUCCESS',
      performedBy: user._id,
      metadata: { ip: req.ip, userAgent: req.headers['user-agent'] }
    });

  } catch (error) {
    console.error('AD Login Error:', error);
    
    await AuditLog.create({
      category: 'Logins',
      action: 'LOGIN_FAILED',
      metadata: { attemptedUsername: username, ip: req.ip, reason: error.message }
    }).catch(console.error);

    res.status(401).json({ message: `Login failed: ${error.message}` });
  }
};

module.exports = {
  login
};
