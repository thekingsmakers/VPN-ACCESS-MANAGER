const AccessRecord = require('../models/AccessRecord');
const Request = require('../models/Request');
const User = require('../models/User');

const getDetailedReport = async (req, res) => {
  try {
    const { startDate, endDate, search } = req.query;
    
    let query = {};
    
    // Date Filtering
    if (startDate || endDate) {
      query.startDate = {};
      if (startDate) query.startDate.$gte = new Date(startDate);
      if (endDate) query.startDate.$lte = new Date(endDate);
    }
    
    // Fetch records with deep population
    let records = await AccessRecord.find(query)
      .populate({
        path: 'userId',
        select: 'username email fullName role adDn'
      })
      .populate({
        path: 'requestId',
        populate: [
          { path: 'managerId', select: 'username email fullName' },
          { path: 'securityAdminId', select: 'username email fullName' },
          { path: 'itAdminId', select: 'username email fullName' }
        ]
      })
      .sort({ startDate: -1 });

    // Client-side filtering for search (User/Email/Grantor) if search is provided
    if (search) {
      const s = search.toLowerCase();
      records = records.filter(r => {
        const user = r.userId?.username?.toLowerCase() || '';
        const name = r.userId?.fullName?.toLowerCase() || '';
        const email = r.userId?.email?.toLowerCase() || '';
        const grantor = r.requestId?.itAdminId?.username?.toLowerCase() || '';
        
        return user.includes(s) || name.includes(s) || email.includes(s) || grantor.includes(s);
      });
    }

    res.json(records);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getSummaryStats = async (req, res) => {
  try {
    const totalActive = await AccessRecord.countDocuments({ status: 'active' });
    const totalRequests = await Request.countDocuments();
    const totalUsers = await User.countDocuments();
    
    // Aggregation for Top Requesters
    const topUsers = await AccessRecord.aggregate([
      { $group: { _id: "$userId", count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 5 },
      { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'userInfo' } },
      { $unwind: "$userInfo" },
      { $project: { username: "$userInfo.username", count: 1 } }
    ]);

    res.json({
      totalActive,
      totalRequests,
      totalUsers,
      topUsers
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getDetailedReport,
  getSummaryStats
};
