const mongoose = require('mongoose');

let isConnected = false;

const connectDB = async () => {
  try {
    if (!process.env.MONGO_URI) {
       console.log("[MongoDB] Configuration missing. Waiting for native Setup Hub parameters.");
       return false;
    }
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
    isConnected = true;
    return true;
  } catch (error) {
    console.error(`Error config DB: ${error.message} - Awaiting Setup Bootstrap.`);
    return false;
  }
};

const getDbState = () => isConnected;

module.exports = { connectDB, getDbState };
