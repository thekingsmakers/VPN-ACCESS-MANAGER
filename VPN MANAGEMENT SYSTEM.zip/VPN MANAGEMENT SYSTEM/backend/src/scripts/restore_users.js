const mongoose = require('mongoose');
const path = require('path');
const dotenv = require('dotenv');

// Load env from project root
dotenv.config({ path: path.join(__dirname, '../../../.env') });

const AccessRecord = require('../models/AccessRecord');

async function restoreRevokedUsers() {
  try {
    const mongoUri = process.env.MONGO_URI || 'mongodb://localhost:27017/vpn_management';
    await mongoose.connect(mongoUri);
    console.log('Connected to MongoDB.');

    // Find all records revoked due to AD sync error recently
    const targetReason = 'ad_group_removed';
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);

    const recordsToRestore = await AccessRecord.find({
      status: 'revoked',
      removalReason: targetReason,
      updatedAt: { $gte: oneHourAgo }
    });

    if (recordsToRestore.length === 0) {
      console.log('No recently revoked records found to restore.');
      process.exit(0);
    }

    console.log(`Found ${recordsToRestore.length} records to restore.`);

    for (const record of recordsToRestore) {
      // Logic: if already expired naturally, extend to 7 days, else just reactive
      if (record.endDate < new Date()) {
         record.endDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      }

      record.status = 'active';
      record.removalReason = null;
      await record.save();
      console.log(`Restored access for record ID: ${record._id}`);
    }

    console.log('Restoration complete.');
    process.exit(0);
  } catch (err) {
    console.error('Restoration failed:', err);
    process.exit(1);
  }
}

restoreRevokedUsers();
