/**
 * VPN Portal - AD Service Account Password Updater
 * 
 * Usage:
 *   node src/scripts/update_ad_password.js
 * 
 * Run this from the /backend directory when the vpnmngr service
 * account password has changed in Active Directory.
 */

require('dotenv').config();
const mongoose = require('mongoose');
const crypto = require('crypto');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const question = (prompt) => new Promise(resolve => rl.question(prompt, resolve));

const encryptPassword = (plainText) => {
  const rawKey = process.env.ENCRYPTION_KEY;
  if (!rawKey || rawKey.length < 32) throw new Error('ENCRYPTION_KEY not found or too short in .env');

  // Must match backend src/utils/crypto.js exactly:
  // key = first 32 UTF-8 chars of the raw ENCRYPTION_KEY string
  // algorithm = aes-256-gcm
  // format = iv:authTag:encryptedData (all hex)
  const key = Buffer.from(rawKey.slice(0, 32), 'utf-8');
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);

  let encrypted = cipher.update(plainText, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');

  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
};

const run = async () => {
  console.log('');
  console.log('=======================================================');
  console.log('  VPN Portal - AD Service Account Password Updater');
  console.log('=======================================================');
  console.log('');

  // Show current stored config
  console.log('Connecting to database...');
  await mongoose.connect(process.env.MONGO_URI);
  const db = mongoose.connection.db;
  const settings = await db.collection('settings').findOne({});

  if (!settings?.activeDirectory) {
    console.error('[ERROR] No Active Directory configuration found in the database.');
    console.error('        Please complete the Setup at http://localhost:444/setup first.');
    process.exit(1);
  }

  console.log('');
  console.log('Current AD Configuration:');
  console.log('  URL      :', settings.activeDirectory.url);
  console.log('  Username :', settings.activeDirectory.username);
  console.log('  Base DN  :', settings.activeDirectory.baseDn);
  console.log('');

  const confirm = await question('Update the password for this account? (yes/no): ');
  if (confirm.toLowerCase() !== 'yes') {
    console.log('Aborted. No changes made.');
    rl.close();
    process.exit(0);
  }

  console.log('');
  let newPassword;
  try {
    newPassword = await question('Enter new AD service account password: ');
  } catch (e) {
    console.error('\n[ERROR] Could not read input:', e.message);
    process.exit(1);
  }

  if (!newPassword || newPassword.trim() === '') {
    console.error('\n[ERROR] Password cannot be empty.');
    process.exit(1);
  }

  console.log('');
  console.log('Encrypting and saving...');

  const encryptedPassword = encryptPassword(newPassword);

  await db.collection('settings').updateOne(
    {},
    { $set: { 'activeDirectory.encryptedPassword': encryptedPassword } }
  );

  console.log('');
  console.log('=======================================================');
  console.log('  SUCCESS! AD service account password updated.');
  console.log('');
  console.log('  Next step: Restart the backend for changes to take effect.');
  console.log('  Run: node src\\server.js');
  console.log('=======================================================');
  console.log('');

  rl.close();
  process.exit(0);
};

run().catch(err => {
  console.error('\n[FATAL ERROR]', err.message);
  process.exit(1);
});
