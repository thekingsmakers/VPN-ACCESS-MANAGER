const mongoose = require('mongoose');
const path = require('path');
const dotenv = require('dotenv');

// Load env from project root
dotenv.config({ path: path.join(__dirname, '../../../.env') });

const AccessRecord = require('../models/AccessRecord');

async function pruneDuplicates() {
  try {
    const mongoUri = process.env.MONGO_URI || 'mongodb://localhost:27017/vpn_management';
    await mongoose.connect(mongoUri);
    console.log('Connected to MongoDB.');

    // Aggregate to find users with multiple active records
    const duplicates = await AccessRecord.aggregate([
      { $match: { status: 'active' } },
      { $group: {
          _id: "$userId",
          count: { $sum: 1 },
          records: { $push: "$$ROOT" }
      }},
      { $match: { count: { $gt: 1 } } }
    ]);

    if (duplicates.length === 0) {
      console.log('No duplicates found.');
      process.exit(0);
    }

    console.log(`Analyzing ${duplicates.length} users with redundant active connections...`);

    let totalPruned = 0;

    for (const entry of duplicates) {
      // Sort records by endDate descending (keep the one that expires last)
      const sorted = entry.records.sort((a, b) => new Date(b.endDate) - new Date(a.endDate));
      
      const toKeep = sorted[0];
      const toPrune = sorted.slice(1);

      console.log(`User ID ${entry._id}: Keeping ${toKeep._id} (Expires: ${toKeep.endDate}), Pruning ${toPrune.length} others.`);

      for (const record of toPrune) {
        await AccessRecord.findByIdAndUpdate(record._id, { 
          status: 'revoked', 
          removalReason: 'manually_revoked',
          endDate: new Date()
        });
        totalPruned++;
      }
    }

    console.log(`Pruning complete. Total records revoked: ${totalPruned}`);
    process.exit(0);
  } catch (err) {
    console.error('Pruning failed:', err);
    process.exit(1);
  }
}

pruneDuplicates();
