@echo off
echo ===================================================
echo VPN Portal - Access Restoration Utility
echo ===================================================
echo.
echo This script will restore records that were accidentally
echo revoked during the AD synchronization mismatch error.
echo.

node "backend\src\scripts\restore_users.js"

if %ERRORLEVEL% equ 0 (
    echo.
    echo Restoration successfully completed.
) else (
    echo.
    echo Error: Restoration script failed. Please check the logs above.
)

pause
