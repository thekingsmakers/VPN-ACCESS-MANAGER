import React, { useEffect, useState, createContext } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import axios from 'axios';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import SetupHub from './components/SetupHub';

export const SettingsContext = createContext({ branding: {}, vpnDurations: [] });

// A simple Auth Guard
const ProtectedRoute = ({ children }) => {
  const token = localStorage.getItem('token');
  if (!token) return <Navigate to="/login" replace />;
  return children;
};

function App() {
  const [globalSettings, setGlobalSettings] = useState(null);

  useEffect(() => {
    axios.get(`/api/settings/public?t=${new Date().getTime()}`)
      .then(res => {
        setGlobalSettings(res.data);
        if (res.data.branding) {
           document.title = res.data.branding.portalName || 'VPN Access Portal';
           const root = document.documentElement;
           if (res.data.branding.primaryColor) root.style.setProperty('--color-primary', res.data.branding.primaryColor);
           if (res.data.branding.secondaryColor) root.style.setProperty('--color-secondary', res.data.branding.secondaryColor);
           if (res.data.branding.backgroundColor) root.style.setProperty('--color-bg', res.data.branding.backgroundColor);
        }
      })
      .catch(console.error);
  }, []);

  if (!globalSettings) return <div className="p-8 text-center text-slate-500 flex flex-col items-center justify-center min-h-screen bg-slate-900"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mb-4"></div>Initializing VPN infrastructure...</div>;

  return (
    <SettingsContext.Provider value={globalSettings}>
      <BrowserRouter>
        <div className="min-h-screen" style={{ backgroundColor: 'var(--color-bg, #f8fafc)' }}>
          <Routes>
            {globalSettings.isSetupComplete === false ? (
              <>
                <Route path="/setup" element={<SetupHub isMongoConnected={globalSettings.isMongoConnected} />} />
                <Route path="*" element={<Navigate to="/setup" replace />} />
              </>
            ) : (
              <>
                <Route path="/login" element={<Login />} />
                <Route 
                  path="/dashboard/*" 
                  element={
                    <ProtectedRoute>
                      <Dashboard />
                    </ProtectedRoute>
                  } 
                />
                <Route path="*" element={<Navigate to="/dashboard" replace />} />
              </>
            )}
          </Routes>
        </div>
      </BrowserRouter>
    </SettingsContext.Provider>
  );
}

export default App;
