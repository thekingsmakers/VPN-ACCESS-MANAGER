import React, { useState } from 'react';
import { Database, Upload, AlertCircle, CheckCircle2, XCircle, Download } from 'lucide-react';

const ProvisionPanel = ({ api }) => {
  const [csvText, setCsvText] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      setCsvText(evt.target.result);
    };
    reader.readAsText(file);
  };

  const handleDownloadTemplate = () => {
    const templateContent = "username, email_address, duration_days\njdoe_admin, jdoe@domain.com, 14\nasmith, asmith@domain.com, 30";
    const blob = new Blob([templateContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'VPN_Bulk_Provisioning_Template.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const handleBulkDeploy = async () => {
    if (!csvText.trim()) return;
    setLoading(true);
    setResults(null);

    // Basic CSV parse
    const lines = csvText.trim().split('\n');
    const payload = [];

    // Skip header if it exists intuitively (e.g. if row starts with username/email)
    let startIndex = 0;
    if (lines[0].toLowerCase().includes('username')) {
      startIndex = 1;
    }

    for (let i = startIndex; i < lines.length; i++) {
       const row = lines[i].split(',').map(s => s.trim());
       if (row.length >= 2) {
         payload.push({
           username: row[0],
           email: row[1],
           durationDays: row[2] ? Number(row[2]) : 7
         });
       }
    }

    if (payload.length === 0) {
      setLoading(false);
      return alert('No valid rows mapped! Format: username, email, durationDays');
    }

    try {
      const res = await api.post('/requests/batch-provision', { payload });
      setResults(res.data.results);
      setCsvText('');
    } catch(err) {
      alert('Deployment Array Failed: ' + (err.response?.data?.message || err.message));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight flex items-center">
          <Database className="w-8 h-8 mr-3 text-slate-700" /> Direct Deployment Engine
        </h1>
        <p className="text-slate-500 mt-1">Headless mass-provisioning hub explicitly bypassing sequential workflows.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* CSV Processor */}
        <div className="glass p-6 rounded-2xl border shadow-sm">
           <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center">
             <Upload className="w-5 h-5 mr-2 text-indigo-600" /> Upload CSV Source Map
           </h3>
           <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-xl text-sm mb-6 flex items-start space-x-3">
             <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
             <p><strong>Warning:</strong> Native batch provisions skip all intermediary pipelines (Manager/Sec). Active Directory mappings and automated HTTP Emails are dispatched perfectly instantly upon executing this node payload.</p>
           </div>

           <div className="mb-4 text-sm font-medium text-slate-700 bg-slate-50 border border-slate-200 p-4 rounded-xl flex items-center justify-between">
             <div className="flex flex-col space-y-2">
               <span>Load directly from physical machine:</span>
               <button onClick={handleDownloadTemplate} className="flex items-center text-xs text-indigo-600 hover:text-indigo-800 font-bold transition-colors">
                 <Download className="w-3.5 h-3.5 mr-1" /> Download CSV Template
               </button>
             </div>
             <input 
               type="file" 
               accept=".csv" 
               onChange={handleFileUpload} 
               className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer"
             />
           </div>

           <label className="block text-sm font-semibold text-slate-700 mb-2">
             Or Paste Native CSV Values Directly
           </label>
           <p className="text-xs text-slate-500 mb-4">Required formatting mapping: <code className="bg-slate-100 px-1 py-0.5 rounded font-bold text-slate-700">username, email_address, duration_days</code></p>
           
           <textarea 
             className="w-full h-64 bg-slate-900 border-0 text-green-400 font-mono text-sm p-4 rounded-xl shadow-inner focus:ring-2 focus:ring-indigo-500 outline-none resize-none placeholder-slate-600 leading-relaxed"
             placeholder={`jdoe_admin, jdoe@domain.com, 14\nasmith, asmith@domain.com, 30\nrjohns, rjohns@domain.com, 7`}
             value={csvText}
             onChange={(e) => setCsvText(e.target.value)}
           ></textarea>

           <button 
             onClick={handleBulkDeploy}
             disabled={loading || !csvText.trim()}
             className="w-full mt-6 flex items-center justify-center space-x-2 py-3.5 rounded-xl border border-indigo-200 bg-indigo-600 text-white hover:bg-indigo-700 transition disabled:opacity-50 disabled:cursor-not-allowed font-medium shadow-md shadow-indigo-500/30"
           >
             <Upload className="w-4 h-4" />
             <span>{loading ? 'Mapping Payloads & Establishing Tunnels...' : 'Initiate Headless Bulk Deployment'}</span>
           </button>
        </div>

        {/* Results Matrix */}
        <div className="glass p-6 rounded-2xl border shadow-sm flex flex-col justify-between min-h-[400px]">
           <div>
             <h3 className="text-xl font-bold text-slate-800 mb-6 border-b border-slate-200 pb-4">Deployment Terminal Logs</h3>
             
              {results ? (
                <div className="space-y-5">
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
                      <p className="text-xs font-bold text-green-700 uppercase tracking-widest mb-1">Mapped</p>
                      <p className="text-3xl font-black text-green-600">{results.success}</p>
                    </div>
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-center">
                      <p className="text-xs font-bold text-amber-700 uppercase tracking-widest mb-1">Skipped</p>
                      <p className="text-3xl font-black text-amber-600">{results.skipped || 0}</p>
                    </div>
                    <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-center">
                      <p className="text-xs font-bold text-red-700 uppercase tracking-widest mb-1">Failed</p>
                      <p className="text-3xl font-black text-red-600">{results.failed}</p>
                    </div>
                  </div>

                  {results.skippedUsers?.length > 0 && (
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                      <h4 className="font-bold text-amber-800 text-sm mb-3 flex items-center">
                        <AlertCircle className="w-4 h-4 mr-2" /> Skipped — User Already Has Active Access:
                      </h4>
                      <ul className="space-y-1.5 text-xs font-mono text-amber-700 max-h-32 overflow-y-auto">
                        {results.skippedUsers.map((s, idx) => (
                          <li key={idx} className="flex items-start">
                            <span className="mr-2 text-amber-400 font-bold">→</span>
                            <span>{s}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {results.errors?.length > 0 && (
                    <div className="bg-slate-100 border border-slate-200 rounded-xl p-4">
                      <h4 className="font-bold text-slate-800 text-sm mb-3">System Exceptions:</h4>
                      <ul className="space-y-1.5 text-xs font-mono text-red-600 max-h-32 overflow-y-auto">
                        {results.errors.map((e, idx) => (
                          <li key={idx} className="flex">
                            <XCircle className="w-3.5 h-3.5 mr-2 shrink-0 mt-0.5" />
                            <span className="truncate">{e}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-48 text-slate-400">
                   <Database className="w-12 h-12 mb-3 opacity-20" />
                   <p>Awaiting deployment payloads...</p>
                </div>
              )}
            </div>
        </div>

      </div>
    </div>
  );
};

export default ProvisionPanel;
