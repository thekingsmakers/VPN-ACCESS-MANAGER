import React, { useEffect, useState } from 'react';
import { ShieldAlert, Plus, ShieldCheck, RefreshCw } from 'lucide-react';

import { SettingsContext } from '../App';

const AccessPanel = ({ api }) => {
  const globalSettings = React.useContext(SettingsContext);
  const [accessRecords, setAccessRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [extendModal, setExtendModal] = useState({ show: false, id: null, duration: 3, justification: '', isCustom: false });
  const [msg, setMsg] = useState(null);

  const fetchAccess = async () => {
    try {
      const res = await api.get('/requests/access/my');
      setAccessRecords(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAccess();
  }, [api]);

  const handleExtend = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post(`/requests/extend/${extendModal.id}`, {
        durationDays: Number(extendModal.duration),
        justification: extendModal.justification
      });
      setMsg({ text: res.data.message || 'Extension submitted successfully', type: 'success' });
      setExtendModal({ show: false, id: null, duration: 3, justification: '', isCustom: false });
      fetchAccess();
    } catch (err) {
      setMsg({ text: err.response?.data?.message || 'Error processing extension', type: 'error' });
      setExtendModal({ show: false, id: null, duration: 3, justification: '', isCustom: false });
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Active Access</h1>
          <p className="text-slate-500 mt-1">Manage your current VPN tunnel provisions.</p>
        </div>
        <button onClick={fetchAccess} className="p-2 bg-white rounded-full text-slate-500 hover:text-blue-600 shadow-sm border transition">
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>

      {msg && (
        <div className={`p-4 rounded-xl mb-6 flex items-center space-x-3 text-sm ${msg.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
          <span>{msg.text}</span>
          <button className="ml-auto text-inherit font-bold font-lg hover:opacity-70" onClick={() => setMsg(null)}>×</button>
        </div>
      )}

      {loading ? (
        <div className="text-slate-500">Loading your access records...</div>
      ) : accessRecords.length === 0 ? (
        <div className="glass p-12 rounded-2xl text-center shadow-sm">
          <div className="bg-slate-100 text-slate-400 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 border">
            <ShieldAlert className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-medium text-slate-700 mb-2">No Active VPN Access</h2>
          <p className="text-slate-500 max-w-sm mx-auto">You do not currently have any active VPN connections. Submit a new request in the Requests tab.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {accessRecords.map(record => (
            <div key={record._id} className={`glass p-6 rounded-2xl border shadow-sm flex flex-col justify-between ${record.status === 'revoked' ? 'bg-red-50/10 border-red-100' : ''}`}>
              <div>
                <div className="flex justify-between items-start mb-4">
                  {record.status === 'revoked' ? (
                    <div className="bg-red-50 px-3 py-1 rounded-full text-red-700 text-xs font-semibold flex items-center border border-red-200 scale-95 origin-left">
                      <ShieldAlert className="w-4 h-4 mr-1" /> REVOKED
                    </div>
                  ) : (
                    <div className="bg-green-50 px-3 py-1 rounded-full text-green-700 text-xs font-semibold flex items-center border border-green-200">
                      <ShieldCheck className="w-4 h-4 mr-1" /> ACTIVE
                    </div>
                  )}
                  <span className={`text-xs font-bold uppercase tracking-wide ${record.status === 'revoked' ? 'text-red-500' : 'text-slate-500'}`}>
                    {record.status === 'revoked' ? 'ACCESS TERMINATED' : 'SECURE TUNNEL PROVISIONED'}
                  </span>
                </div>
                
                <div className="mb-6">
                  <h3 className={`text-lg font-bold mb-2 ${record.status === 'revoked' ? 'text-red-900 line-through opacity-60' : 'text-slate-800'}`}>Standard Work VPN Provision</h3>
                  <div className={`space-y-1 text-sm text-slate-600 ${record.status === 'revoked' ? 'opacity-70 line-through' : ''}`}>
                    <p><span className="font-medium text-slate-700">Valid From:</span> {new Date(record.startDate).toLocaleDateString()}</p>
                    <p><span className="font-medium text-slate-700">Expires On:</span> <span className="text-amber-600 font-semibold">{new Date(record.endDate).toLocaleDateString()}</span></p>
                  </div>
                  {record.status === 'revoked' && (
                    <p className="text-xs font-bold text-red-600 mt-3 p-2 bg-white rounded border border-red-100 shadow-sm text-center">Connection forcefully terminated by IT Administration.</p>
                  )}
                </div>
              </div>
              
              {record.status === 'revoked' ? (
                <div className="w-full text-center py-2.5 rounded-xl border border-red-100 bg-red-50/50 text-red-400 font-semibold text-sm cursor-not-allowed uppercase tracking-wider">
                   Access Locked
                </div>
              ) : (globalSettings?.workflow?.disableUserRequests) ? (
                <div className="w-full text-center py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-400 font-semibold text-xs uppercase tracking-wider">
                   Extensions Disabled Natively
                </div>
              ) : (
                <button 
                  onClick={() => setExtendModal({ show: true, id: record._id, duration: 3, justification: '', isCustom: false })}
                  className="w-full flex items-center justify-center space-x-2 py-2.5 rounded-xl border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-600 hover:text-white transition-colors font-medium shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Extend Access</span>
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Extension Modal */}
      {extendModal.show && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
          <div className="glass w-full max-w-md rounded-2xl p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <h3 className="text-xl font-bold text-slate-800 mb-1">Extend VPN Access</h3>
            <p className="text-sm text-slate-500 mb-6">
              {globalSettings?.workflow?.autoApproveExtensions !== false 
                ? `Need more time? Extensions ≤ ${globalSettings?.workflow?.maxAutoExtensionDays || 3} days are auto-approved.`
                : 'Need more time? All extensions must clear the standard administrative matrix.'}
            </p>
            
            <form onSubmit={handleExtend} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5 flex justify-between">
                  <span>Duration</span>
                  {(globalSettings?.workflow?.autoApproveExtensions !== false && Number(extendModal.duration) <= (globalSettings?.workflow?.maxAutoExtensionDays || 3)) && (
                    <span className="text-green-600 font-semibold text-xs py-0.5 px-2 bg-green-50 rounded-md border border-green-200">Auto-Approve</span>
                  )}
                </label>
                <select 
                  className="w-full border-slate-200 bg-white px-3 py-2 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 shadow-sm mb-3"
                  value={extendModal.isCustom ? 'custom' : extendModal.duration}
                  onChange={(e) => setExtendModal({ ...extendModal, duration: Number(e.target.value), justification: extendModal.justification })}
                >
                  {globalSettings?.vpnDurations?.map(dur => {
                     const isAuto = globalSettings?.workflow?.autoApproveExtensions !== false && dur.days <= (globalSettings?.workflow?.maxAutoExtensionDays || 3);
                     return <option key={dur.days} value={dur.days}>{isAuto ? 'Auto-Approve: ' : ''}{dur.label}</option>;
                  })}

                </select>


              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Justification</label>
                <textarea 
                   required
                   className="w-full border-slate-200 bg-white px-3 py-2 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 h-24 resize-none shadow-sm"
                   placeholder="Why do you need an extension?"
                   value={extendModal.justification}
                   onChange={(e) => setExtendModal({...extendModal, justification: e.target.value})}
                />
              </div>
              <div className="flex space-x-3 pt-2">
                <button type="button" onClick={() => setExtendModal({ show: false, id: null, duration: 3, justification: '', isCustom: false })} className="flex-1 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-medium hover:bg-slate-200 transition">Cancel</button>
                <button type="submit" className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium shadow-md shadow-blue-500/30 transition">Submit Request</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccessPanel;
