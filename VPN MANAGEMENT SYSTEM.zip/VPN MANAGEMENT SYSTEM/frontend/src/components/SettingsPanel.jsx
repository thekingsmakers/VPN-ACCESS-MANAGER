import React, { useEffect, useState } from 'react';
import { Settings, Save, Server, Shield, Palette, Clock, Mail, CheckSquare, FileText, Megaphone } from 'lucide-react';

const SettingsPanel = ({ api }) => {
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);
  
  const [activeTab, setActiveTab] = useState('branding');

  useEffect(() => {
    fetchSettings();
  }, [api]);

  const fetchSettings = async () => {
    try {
      const res = await api.get('/settings');
      setSettings(res.data);
    } catch (err) {
      console.error(err);
      setMsg({ type: 'error', text: 'Failed to load configuration.' });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      const res = await api.put('/settings', settings);
      setMsg({ type: 'success', text: 'Global configuration updated successfully.' });
      setSettings(res.data);
    } catch (err) {
      setMsg({ type: 'error', text: err.response?.data?.message || 'Error updating settings.' });
    }
  };

  const handleDurationChange = (index, field, value) => {
    const newDurations = [...settings.vpnDurations];
    newDurations[index][field] = field === 'days' ? Number(value) : value;
    setSettings({...settings, vpnDurations: newDurations});
  };

  const addDuration = () => {
    setSettings({...settings, vpnDurations: [...settings.vpnDurations, { days: 1, label: 'Custom' }]});
  };

  const removeDuration = (index) => {
    const newDurations = [...settings.vpnDurations];
    newDurations.splice(index, 1);
    setSettings({...settings, vpnDurations: newDurations});
  };

  const handleLogoUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) return alert('Logo must be less than 2MB.');

    const reader = new FileReader();
    reader.onload = (evt) => {
      setSettings(prev => ({
        ...prev, 
        branding: { ...prev.branding, logoBase64: evt.target.result }
      }));
    };
    reader.readAsDataURL(file);
  };

  const handleBgUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) return alert('Background must be less than 2MB.');

    const reader = new FileReader();
    reader.onload = (evt) => {
      setSettings(prev => ({
        ...prev, 
        branding: { ...prev.branding, loginBackgroundBase64: evt.target.result }
      }));
    };
    reader.readAsDataURL(file);
  };

  if (loading) return <div className="text-slate-500 p-8">Loading System Configurator...</div>;
  if (!settings) return null;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight flex items-center">
            <Settings className="w-8 h-8 mr-3 text-slate-700" /> IT Configurator
          </h1>
          <p className="text-slate-500 mt-1">Manage global web application state, branding, and core infrastructure.</p>
        </div>
        <button onClick={handleSave} className="flex items-center space-x-2 bg-slate-800 hover:bg-slate-900 text-white px-5 py-2.5 rounded-xl font-medium transition shadow-md">
          <Save className="w-4 h-4" /> <span>Save All Changes</span>
        </button>
      </div>

      {msg && (
        <div className={`p-4 rounded-xl mb-6 flex justify-between text-sm ${msg.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
          <span>{msg.text}</span>
          <button onClick={() => setMsg(null)} className="font-bold opacity-70 hover:opacity-100">×</button>
        </div>
      )}

      <div className="flex flex-col md:flex-row gap-8">
        
        {/* Settings Navigation */}
        <div className="w-full md:w-64 shrink-0">
          <div className="glass rounded-2xl border p-2 space-y-1">
            <NavBtn id="branding" label="Branding & UI" icon={Palette} active={activeTab} setActive={setActiveTab} />
            <NavBtn id="workflow" label="Workflow Rules" icon={CheckSquare} active={activeTab} setActive={setActiveTab} />
            <NavBtn id="durations" label="VPN Durations" icon={Clock} active={activeTab} setActive={setActiveTab} />
            <NavBtn id="ldap" label="Active Directory" icon={Shield} active={activeTab} setActive={setActiveTab} />
            <NavBtn id="smtp" label="SMTP Server" icon={Mail} active={activeTab} setActive={setActiveTab} />
            <NavBtn id="email_templates" label="Email Templates" icon={FileText} active={activeTab} setActive={setActiveTab} />
            <NavBtn id="broadcasting" label="Global Broadcasting" icon={Megaphone} active={activeTab} setActive={setActiveTab} />
          </div>
        </div>

        {/* Configuration Panel */}
        <div className="flex-1 glass rounded-2xl border p-8 shadow-sm">
          
          <form className="space-y-6">
            {activeTab === 'workflow' && (
              <div className="space-y-5 animate-in fade-in duration-300">
                <h3 className="text-xl font-semibold text-slate-800 mb-6 border-b pb-4">Approval Routing Pipeline</h3>
                <div className="bg-white/50 border border-slate-200 rounded-xl p-5 shadow-sm">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h4 className="font-bold text-slate-800">Require Manager Approval</h4>
                      <p className="text-sm text-slate-500">Route requests to the user's supervisor before secondary assessments.</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" checked={settings.workflow?.requireManagerApproval ?? true} onChange={e => setSettings({...settings, workflow: {...settings.workflow, requireManagerApproval: e.target.checked}})} />
                      <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                    </label>
                  </div>
                </div>

                <div className="bg-white/50 border border-slate-200 rounded-xl p-5 shadow-sm">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h4 className="font-bold text-slate-800">Require IT Security Assessment</h4>
                      <p className="text-sm text-slate-500">Route requests to the IT Security Team before IT Admin provisioning.</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" checked={settings.workflow?.requireSecurityApproval ?? true} onChange={e => setSettings({...settings, workflow: {...settings.workflow, requireSecurityApproval: e.target.checked}})} />
                      <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                    </label>
                  </div>
                </div>

                <div className="bg-white/50 border border-slate-200 rounded-xl p-5 shadow-sm">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h4 className="font-bold text-slate-800">Require IT Admin Provisioning Review</h4>
                      <p className="text-sm text-slate-500">Route requests to IT Admin. (WARNING: Skipping this auto-provisions Active Directory).</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" checked={settings.workflow?.requireITAdminApproval ?? true} onChange={e => setSettings({...settings, workflow: {...settings.workflow, requireITAdminApproval: e.target.checked}})} />
                      <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                    </label>
                  </div>
                </div>

                <div className="bg-white/50 border border-slate-200 rounded-xl p-5 shadow-sm mt-8 border-t-4 border-t-indigo-400">
                  <h3 className="text-lg font-bold text-slate-800 mb-4">VPN Extensions Tuning</h3>
                  
                  <div className="flex items-center justify-between mb-5 bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
                    <div>
                      <h4 className="font-bold text-slate-800">Auto-Approve Extension Renewals</h4>
                      <p className="text-sm text-slate-500 max-w-sm">Skip standard matrix approval chains entirely if the user requests an extension shorter than the defined day threshold below.</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" checked={settings.workflow?.autoApproveExtensions ?? true} onChange={e => setSettings({...settings, workflow: {...settings.workflow, autoApproveExtensions: e.target.checked}})} />
                      <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                    </label>
                  </div>

                  <div className={`transition-all duration-300 ${(!settings.workflow?.autoApproveExtensions) ? 'opacity-50 pointer-events-none' : ''}`}>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5 flex justify-between">
                      <span>Maximum Allowable Auto-Extension Limit (Days)</span>
                    </label>
                    <input 
                      type="number"
                      min="1"
                      className="w-full border-slate-200 bg-white/50 px-3 py-3 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm font-medium"
                      value={settings.workflow?.maxAutoExtensionDays ?? 3}
                      onChange={(e) => setSettings({...settings, workflow: {...settings.workflow, maxAutoExtensionDays: Number(e.target.value)}})}
                    />
                  </div>
                </div>

                <div className="bg-white/50 border border-red-200 rounded-xl p-5 shadow-sm mt-8 border-t-4 border-t-red-500">
                  <h3 className="text-lg font-bold text-slate-800 mb-4">Headless Auto-Provisioning Framework</h3>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
                      <div>
                        <h4 className="font-bold text-red-900">Disable Native User Portal</h4>
                        <p className="text-sm text-slate-500 max-w-md">Lock out all standard users from navigating standard provisioning forms.</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer flex-shrink-0 ml-4">
                        <input type="checkbox" className="sr-only peer" checked={settings.workflow?.disableUserRequests ?? false} onChange={e => setSettings({...settings, workflow: {...settings.workflow, disableUserRequests: e.target.checked}})} />
                        <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-600"></div>
                      </label>
                    </div>

                    <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
                      <div>
                        <h4 className="font-bold text-slate-800">Disable Native Manager Portal</h4>
                        <p className="text-sm text-slate-500 max-w-md">Lock out managers from navigating the Approval matrix entirely.</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer flex-shrink-0 ml-4">
                        <input type="checkbox" className="sr-only peer" checked={settings.workflow?.disableManagerPortal ?? false} onChange={e => setSettings({...settings, workflow: {...settings.workflow, disableManagerPortal: e.target.checked}})} />
                        <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-slate-800"></div>
                      </label>
                    </div>

                    <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
                      <div>
                        <h4 className="font-bold text-slate-800">Disable IT Security Portal</h4>
                        <p className="text-sm text-slate-500 max-w-md">Lock out intermediate IT Security from navigating the Approval matrix.</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer flex-shrink-0 ml-4">
                        <input type="checkbox" className="sr-only peer" checked={settings.workflow?.disableSecurityPortal ?? false} onChange={e => setSettings({...settings, workflow: {...settings.workflow, disableSecurityPortal: e.target.checked}})} />
                        <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-slate-800"></div>
                      </label>
                    </div>

                    <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
                      <div>
                        <h4 className="font-bold text-slate-800">Disable Super Admin Portals</h4>
                        <p className="text-sm text-slate-500 max-w-md">Disable remaining general deployment layouts (Except IT Configurator).</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer flex-shrink-0 ml-4">
                        <input type="checkbox" className="sr-only peer" checked={settings.workflow?.disableAdminPortal ?? false} onChange={e => setSettings({...settings, workflow: {...settings.workflow, disableAdminPortal: e.target.checked}})} />
                        <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-slate-800"></div>
                      </label>
                    </div>
                  </div>
                </div>

              </div>
            )}

            {activeTab === 'branding' && (
              <div className="space-y-5 animate-in fade-in duration-300">
                <h3 className="text-xl font-semibold text-slate-800 mb-6 border-b pb-4">Web Application Branding</h3>
                <Input label="Portal Name" value={settings.branding.portalName} onChange={v => setSettings({...settings, branding: {...settings.branding, portalName: v}})} />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <ColorInput label="Primary Tailwind Color" value={settings.branding.primaryColor} onChange={v => setSettings({...settings, branding: {...settings.branding, primaryColor: v}})} />
                  <ColorInput label="Secondary Selection Color" value={settings.branding.secondaryColor || '#3b82f6'} onChange={v => setSettings({...settings, branding: {...settings.branding, secondaryColor: v}})} />
                  <ColorInput label="Dashboard Background Color" value={settings.branding.backgroundColor || '#f8fafc'} onChange={v => setSettings({...settings, branding: {...settings.branding, backgroundColor: v}})} />
                  
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">System Logo (PNG/JPG)</label>
                    <div className="flex items-center space-x-4 border border-slate-200 bg-white/50 p-2 rounded-xl shadow-sm mb-3">
                      {settings.branding.logoBase64 ? (
                        <div className="relative w-12 h-12 flex-shrink-0 bg-slate-100 rounded-lg overflow-hidden border">
                          <img src={settings.branding.logoBase64} alt="Logo" className="w-full h-full object-contain" />
                          <button type="button" onClick={() => setSettings({...settings, branding: {...settings.branding, logoBase64: ''}})} className="absolute -top-1 -right-1 bg-red-500 text-white w-4 h-4 rounded-full text-[10px] flex items-center justify-center font-bold">×</button>
                        </div>
                      ) : (
                        <div className="w-12 h-12 flex-shrink-0 bg-slate-100 rounded-lg border border-dashed border-slate-300 flex items-center justify-center">
                          <Palette className="w-5 h-5 text-slate-400" />
                        </div>
                      )}
                      <input 
                        type="file" 
                        accept="image/png, image/jpeg, image/svg+xml" 
                        onChange={handleLogoUpload} 
                        className="file:mr-4 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 w-full text-xs text-slate-500 cursor-pointer"
                      />
                    </div>
                    <Input label="Or Extenernal Logo URL String" value={settings.branding.logoUrl || ''} onChange={v => setSettings({...settings, branding: {...settings.branding, logoUrl: v}})} placeholder="https://..." />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Login Page Background Array</label>
                    <div className="flex items-center space-x-4 border border-slate-200 bg-white/50 p-2 rounded-xl shadow-sm mb-3">
                      {settings.branding.loginBackgroundBase64 ? (
                        <div className="relative w-12 h-12 flex-shrink-0 bg-slate-100 rounded-lg overflow-hidden border">
                          <img src={settings.branding.loginBackgroundBase64} alt="Bg" className="w-full h-full object-cover" />
                          <button type="button" onClick={() => setSettings({...settings, branding: {...settings.branding, loginBackgroundBase64: ''}})} className="absolute -top-1 -right-1 bg-red-500 text-white w-4 h-4 rounded-full text-[10px] flex items-center justify-center font-bold">×</button>
                        </div>
                      ) : (
                        <div className="w-12 h-12 flex-shrink-0 bg-slate-100 rounded-lg border border-dashed border-slate-300 flex items-center justify-center">
                          <Palette className="w-5 h-5 text-slate-400" />
                        </div>
                      )}
                      <input 
                        type="file" 
                        accept="image/png, image/jpeg" 
                        onChange={handleBgUpload} 
                        className="file:mr-4 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 w-full text-xs text-slate-500 cursor-pointer"
                      />
                    </div>
                    <Input label="Or External Background URL" value={settings.branding.loginBackgroundUrl || ''} onChange={v => setSettings({...settings, branding: {...settings.branding, loginBackgroundUrl: v}})} placeholder="https://..." />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'durations' && (
              <div className="space-y-5 animate-in fade-in duration-300">
                <h3 className="text-xl font-semibold text-slate-800 mb-6 border-b pb-4">Allowed VPN Terms</h3>
                <p className="text-sm text-slate-500 mb-4">Define the maximum number of days a user can request VPN access. They will select from these options.</p>
                
                <div className="space-y-3">
                  {settings.vpnDurations.map((dur, i) => (
                    <div key={i} className="flex items-center space-x-3 bg-white/50 p-3 rounded-xl border border-slate-200">
                      <div className="flex-1 input-group">
                        <label className="text-xs text-slate-400 font-semibold uppercase block mb-1">Days</label>
                        <input type="number" value={dur.days} onChange={e => handleDurationChange(i, 'days', e.target.value)} className="w-full bg-transparent border-b border-slate-300 focus:border-indigo-500 outline-none pb-1" />
                      </div>
                      <div className="flex-1 input-group">
                        <label className="text-xs text-slate-400 font-semibold uppercase block mb-1">UI Label</label>
                        <input type="text" value={dur.label} onChange={e => handleDurationChange(i, 'label', e.target.value)} className="w-full bg-transparent border-b border-slate-300 focus:border-indigo-500 outline-none pb-1" />
                      </div>
                      <button type="button" onClick={() => removeDuration(i)} className="p-2 text-red-400 hover:bg-red-50 hover:text-red-600 rounded-lg transition mt-4">Remove</button>
                    </div>
                  ))}
                </div>
                <button type="button" onClick={addDuration} className="mt-4 px-4 py-2 border border-dashed border-slate-300 text-slate-500 hover:text-indigo-600 hover:border-indigo-300 hover:bg-indigo-50 rounded-xl transition font-medium text-sm">
                  + Add Duration Preset
                </button>
              </div>
            )}

            {activeTab === 'ldap' && (
              <div className="space-y-5 animate-in fade-in duration-300">
                <h3 className="text-xl font-semibold text-slate-800 mb-6 border-b pb-4">AD Group Mappings</h3>
                <Input placeholder="e.g. CN=ITADMINTEAM,OU=Groups..." label="IT Administrators Group (Full DN or CN)" value={settings.adMapping.itAdminGroup} onChange={v => setSettings({...settings, adMapping: {...settings.adMapping, itAdminGroup: v}})} />
                <Input placeholder="e.g. CN=ITSECURITYTEAM,OU=Groups..." label="IT Security / Super Admins Group (Full DN or CN)" value={settings.adMapping.itSecurityGroup} onChange={v => setSettings({...settings, adMapping: {...settings.adMapping, itSecurityGroup: v}})} />
                <Input placeholder="e.g. CN=VPN_USERS,OU=Groups..." label="Default VPN Access Target Group (Full DN or CN)" value={settings.adMapping.defaultVpnGroup} onChange={v => setSettings({...settings, adMapping: {...settings.adMapping, defaultVpnGroup: v}})} />
              </div>
            )}

            {activeTab === 'smtp' && (
              <div className="space-y-5 animate-in fade-in duration-300">
                <h3 className="text-xl font-semibold text-slate-800 mb-6 border-b pb-4">Outbound Email Control</h3>
                <Input label="SMTP Host Server" value={settings.smtp.host} onChange={v => setSettings({...settings, smtp: {...settings.smtp, host: v}})} />
                <div className="flex space-x-4">
                  <div className="flex-1"><Input label="SMTP Port" type="number" value={settings.smtp.port} onChange={v => setSettings({...settings, smtp: {...settings.smtp, port: Number(v)}})} /></div>
                  <div className="flex-[2]"><Input label="From Address" value={settings.smtp.fromAlias || settings.smtp.from} onChange={v => setSettings({...settings, smtp: {...settings.smtp, fromAlias: v}})} /></div>
                </div>

                <div className="flex space-x-8 py-3">
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" checked={settings.smtp.requiresAuth ?? true} onChange={e => setSettings({...settings, smtp: {...settings.smtp, requiresAuth: e.target.checked}})} />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                    <span className="ml-3 text-sm font-bold text-slate-700">Requires Authentication</span>
                  </label>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" checked={settings.smtp.secure ?? false} onChange={e => setSettings({...settings, smtp: {...settings.smtp, secure: e.target.checked}})} />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                    <span className="ml-3 text-sm font-bold text-slate-700">Enforce TLS (Secure)</span>
                  </label>
                </div>

                {(settings.smtp.requiresAuth ?? true) && (
                   <div className="space-y-5">
                      <Input label="SMTP Username" value={settings.smtp.user} onChange={v => setSettings({...settings, smtp: {...settings.smtp, user: v}})} />
                      <Input label="SMTP Password" type="password" value={settings.smtp.pass} onChange={v => setSettings({...settings, smtp: {...settings.smtp, pass: v}})} />
                   </div>
                )}
              </div>
            )}

            {activeTab === 'email_templates' && (
              <div className="space-y-5 animate-in fade-in duration-300">
                <h3 className="text-xl font-semibold text-slate-800 mb-6 border-b pb-4">Dynamic Email Formatting</h3>
                <p className="text-sm text-slate-500 mb-4">Customize the HTML payload outputs sent via SMTP. Secure bindings like <code className="font-bold text-slate-800">[END_DATE]</code> will inject system dates dynamically.</p>
                <TextArea label="VPN Approval Template" value={settings.emailTemplates?.approvalText} onChange={v => setSettings({...settings, emailTemplates: {...settings.emailTemplates, approvalText: v}})} />
                <TextArea label="VPN Rejection Template" value={settings.emailTemplates?.rejectionText} onChange={v => setSettings({...settings, emailTemplates: {...settings.emailTemplates, rejectionText: v}})} />
                <TextArea label="VPN Extension Template" value={settings.emailTemplates?.extensionText} onChange={v => setSettings({...settings, emailTemplates: {...settings.emailTemplates, extensionText: v}})} />
                <TextArea label="Termination / Kill Switch Template" value={settings.emailTemplates?.revokeText} onChange={v => setSettings({...settings, emailTemplates: {...settings.emailTemplates, revokeText: v}})} />
                <TextArea label="7-Day Expiry Warning Template" value={settings.emailTemplates?.expiryWarningText} onChange={v => setSettings({...settings, emailTemplates: {...settings.emailTemplates, expiryWarningText: v}})} placeholder="Triggered systematically 7 days prior to hard termination limits." />
              </div>
            )}

            {activeTab === 'broadcasting' && (
              <div className="space-y-5 animate-in fade-in duration-300">
                <h3 className="text-xl font-semibold text-slate-800 mb-6 border-b pb-4">Global Network Broadcasting</h3>
                <p className="text-sm text-slate-500 mb-4">Launch a high-alert marquee visible continuously across all connected end-user sessions until strict expiration limits.</p>
                
                <TextArea label="Broadcast Message Payload" value={settings.announcement?.message || ''} onChange={v => setSettings({...settings, announcement: {...settings.announcement, message: v}})} placeholder="e.g. ALL VPN TUNNELS WILL BE OFFLINE FOR MAINTENANCE FROM 00:00 - 04:00 UTC" />
                
                <div className="pt-2">
                   <label className="block text-sm font-semibold text-slate-700 mb-1.5 flex justify-between">
                     <span>Broadcast Duration Map</span>
                     {settings.announcement?.expiresAt && <span className="text-blue-600 font-semibold text-xs py-0.5 px-2 bg-blue-50 rounded-md border border-blue-200">Expires: {new Date(settings.announcement.expiresAt).toLocaleString()}</span>}
                   </label>
                   <select 
                     className="w-full border-slate-200 bg-white/50 px-3 py-3 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm font-medium"
                     onChange={(e) => {
                        if (!e.target.value) return setSettings({...settings, announcement: {...settings.announcement, message: '', expiresAt: null}});
                        const mapValue = Number(e.target.value);
                        const future = new Date();
                        future.setHours(future.getHours() + mapValue);
                        setSettings({...settings, announcement: {...settings.announcement, expiresAt: future}});
                     }}
                   >
                     <option value="">-- Clear Broadcast Stream --</option>
                     <option value="1">1 Hour Rotation Cache</option>
                     <option value="4">4 Hour Rotation Cache</option>
                     <option value="12">12 Hour Rotation Cache</option>
                     <option value="24">24 Hour Rotation Cache</option>
                     <option value="168">7 Day Rotation Cache</option>
                   </select>
                </div>
              </div>
            )}
          </form>

        </div>
      </div>
    </div>
  );
};

const NavBtn = ({ id, label, icon: Icon, active, setActive }) => (
  <button 
    onClick={() => setActive(id)}
    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-colors text-left font-medium ${active === id ? 'bg-white shadow-sm border border-slate-200 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'}`}
  >
    <Icon className="w-5 h-5" /> <span>{label}</span>
  </button>
);

const Input = ({ label, value, onChange, type = 'text', placeholder = '' }) => (
  <div>
    <label className="block text-sm font-semibold text-slate-700 mb-1.5">{label}</label>
    <input 
      type={type} 
      value={value} 
      onChange={e => onChange(e.target.value)} 
      placeholder={placeholder}
      className="w-full border-slate-200 bg-white/50 px-4 py-2.5 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
    />
  </div>
);

const TextArea = ({ label, value, onChange, placeholder = '' }) => (
  <div>
    <label className="block text-sm font-semibold text-slate-700 mb-1.5">{label}</label>
    <textarea 
      rows="3"
      value={value} 
      onChange={e => onChange(e.target.value)} 
      placeholder={placeholder}
      className="w-full border-slate-200 bg-white/50 px-4 py-2.5 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm resize-none"
    />
  </div>
);

const ColorInput = ({ label, value, onChange }) => (
  <div>
    <label className="block text-sm font-semibold text-slate-700 mb-1.5">{label}</label>
    <div className="flex items-center space-x-3 w-full border border-slate-200 bg-white/50 p-1.5 px-3 rounded-xl focus-within:ring-2 focus-within:ring-indigo-500 shadow-sm transition">
      <input 
        type="color" 
        value={value} 
        onChange={e => onChange(e.target.value)} 
        className="w-8 h-8 rounded shrink-0 cursor-pointer p-0 border-0 bg-transparent"
      />
      <input 
        type="text" 
        value={value} 
        onChange={e => onChange(e.target.value)} 
        className="flex-1 bg-transparent outline-none uppercase font-mono text-sm text-slate-600 tracking-wide"
      />
    </div>
  </div>
);

export default SettingsPanel;
