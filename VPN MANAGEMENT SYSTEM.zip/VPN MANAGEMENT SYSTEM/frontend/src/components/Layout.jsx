import React from 'react';
import { Shield, LayoutDashboard, Clock, FileText, Component, LogOut, Database, BarChart3 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

import { SettingsContext } from '../App';

const Layout = ({ user, children, activeTab, setActiveTab }) => {
  const navigate = useNavigate();
  const globalSettings = React.useContext(SettingsContext);

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  const menuItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'access', label: 'My Access', icon: Clock }
  ];

  const isHeadlessLockout = globalSettings?.workflow?.disableUserRequests && user?.role === 'user';
  if (!isHeadlessLockout) {
    menuItems.push({ id: 'requests', label: 'Requests', icon: FileText });
  }

  if (['manager', 'it_admin', 'super_admin'].includes(user?.role)) {
    const isManagerLocked = globalSettings?.workflow?.disableManagerPortal && user?.role === 'manager';
    const isSecurityLocked = globalSettings?.workflow?.disableSecurityPortal && user?.role === 'it_admin';
    const isAdminLocked = globalSettings?.workflow?.disableAdminPortal && ['it_admin', 'super_admin'].includes(user?.role);
    
    if (!isManagerLocked && !isSecurityLocked && !(user?.role !== 'super_admin' && isAdminLocked)) {
       menuItems.push({ id: 'approvals', label: 'Approvals Queue', icon: Component });
    }
  }

  if (['it_admin', 'super_admin'].includes(user?.role)) {
    const isAdminLocked = globalSettings?.workflow?.disableAdminPortal && user?.role !== 'super_admin';
    if (!isAdminLocked) {
      menuItems.push({ id: 'provisioning', label: 'Direct Provisioning', icon: Database });
      menuItems.push({ id: 'reports', label: 'Analytics & Reporting', icon: BarChart3 });
      menuItems.push({ id: 'audit', label: 'System Logs', icon: FileText });
    }
  }

  if (user?.role === 'super_admin') {
    menuItems.push({ id: 'settings', label: 'Settings', icon: Shield });
  }

  const primaryStyle = globalSettings?.branding?.primaryColor ? { backgroundColor: globalSettings.branding.primaryColor } : {};

  const isAnnouncementActive = globalSettings?.announcement?.message && 
    globalSettings.announcement.expiresAt && 
    new Date(globalSettings.announcement.expiresAt) > new Date();

  return (
    <div className="flex flex-col h-screen bg-slate-50 font-sans overflow-hidden">
      {isAnnouncementActive && (
        <div className="bg-red-600 text-white font-bold py-2.5 px-4 z-50 text-sm tracking-wide shadow-md flex-shrink-0">
          <marquee scrollamount="8" behavior="scroll">
            <span className="flex items-center"><Shield className="w-4 h-4 mr-3 inline-block" /> {globalSettings.announcement.message} <Shield className="w-4 h-4 ml-3 inline-block" /></span>
          </marquee>
        </div>
      )}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Sidebar */}
        <aside className="w-64 glass border-r flex flex-col justify-between hidden md:flex">
        <div>
          <div className="p-6 flex items-center space-x-3">
            {globalSettings?.branding?.logoBase64 || globalSettings?.branding?.logoUrl ? (
               <img src={globalSettings.branding.logoBase64 || globalSettings.branding.logoUrl} alt="Logo" className="w-8 h-8 rounded object-contain drop-shadow-[0_2px_4px_rgba(0,0,0,0.1)]" />
            ) : (
               <div style={primaryStyle} className="p-2 rounded-xl shadow-lg shadow-blue-500/30">
                 <Shield className="w-6 h-6 text-white" />
               </div>
            )}
            <span className="font-bold text-xl text-slate-800 tracking-tight">{globalSettings?.branding?.portalName || 'VPN Portal'}</span>
          </div>

          <div className="px-4 py-2">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4 px-2">Navigation</p>
            <nav className="space-y-1">
              {menuItems.map(item => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl transition-all duration-300 ${isActive ? 'bg-blue-50/80 text-blue-700 shadow-sm border border-blue-100/50' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`}
                  >
                    <Icon className={`w-5 h-5 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
                    <span className="font-medium">{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        <div className="p-4">
          <div className="glass p-4 rounded-xl mb-4 text-sm border-slate-200">
            <div className="font-medium text-slate-800">{user?.username}</div>
            <div className="text-slate-500 capitalize">{user?.role.replace('_', ' ')}</div>
          </div>
          <button 
            onClick={logout}
            className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-white border border-slate-200 hover:border-red-200 hover:bg-red-50 text-slate-600 hover:text-red-600 rounded-xl transition-colors shadow-sm"
          >
            <LogOut className="w-4 h-4" />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </aside>

        <main className="flex-1 flex flex-col h-full overflow-hidden overflow-y-auto relative">
          <div className="absolute top-0 left-0 w-full h-96 bg-gradient-to-br from-blue-600/5 via-violet-600/5 to-transparent -z-10 pointer-events-none"></div>
          <div className="p-8 max-w-6xl mx-auto w-full z-0">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;
