import React, { useEffect, useState } from 'react';
import { Component, CheckCircle, XCircle } from 'lucide-react';

const ApprovalQueue = ({ api, user }) => {
  const [pendingRequests, setPendingRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchPending = async () => {
    try {
      const res = await api.get('/requests/pending');
      setPendingRequests(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPending();
  }, [api]);

  const handleApproval = async (id, action) => {
    try {
      let prefix = 'it';
      if (user.role === 'manager') prefix = 'manager';
      else if (user.role === 'it_admin') prefix = 'security';
      
      const endpoint = `/requests/${id}/${prefix}-${action}`;
      
      await api.post(endpoint);
      fetchPending();
    } catch (err) {
      alert(err.response?.data?.message || 'Error processing approval');
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Approvals Queue</h1>
        <p className="text-slate-500 mt-1">Review and process pending VPN requests from users.</p>
      </div>

      <div className="glass rounded-2xl border shadow-sm overflow-hidden">
        <div className="p-6 border-b border-white/50 bg-white/30 backdrop-blur-md flex justify-between items-center">
          <div className="flex items-center space-x-2 text-slate-800">
            <Component className="w-5 h-5 text-amber-500" />
            <h2 className="text-lg font-bold">Action Required</h2>
          </div>
          <span className="bg-amber-100 text-amber-800 text-xs px-2.5 py-1 rounded-full font-bold border border-amber-200">
            {pendingRequests.length} Pending
          </span>
        </div>
        
        <div className="p-6 bg-white/20">
          {loading ? (
            <div className="text-center p-8 text-slate-500">Loading queue...</div>
          ) : pendingRequests.length === 0 ? (
            <div className="text-center p-12 text-slate-500 bg-white/40 rounded-xl border border-dashed border-slate-300">
              There are no pending requests requiring your approval.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingRequests.map(req => (
                <div key={req._id} className="bg-white/60 p-5 rounded-xl border border-slate-200 hover:shadow-md transition">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-bold text-slate-800">{req.userId?.username}</h3>
                      <p className="text-sm text-slate-500">{req.userId?.email}</p>
                    </div>
                    <span className="bg-slate-100 text-slate-600 text-xs font-semibold px-2 py-1 rounded-md">{req.durationDays} Days</span>
                  </div>
                  
                  <div className="mb-6">
                    <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-100">
                      "{req.justification || 'No justification provided.'}"
                    </p>
                  </div>
                  
                  <div className="flex space-x-3">
                    <button 
                      onClick={() => handleApproval(req._id, 'approve')}
                      className="flex-1 flex items-center justify-center space-x-1.5 bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-lg text-sm font-medium transition shadow-sm"
                    >
                      <CheckCircle className="w-4 h-4" /> <span>{user.role === 'it_admin' ? 'Assess Security' : user.role === 'super_admin' ? 'Provision VPN' : 'Approve'}</span>
                    </button>
                    <button 
                      onClick={() => handleApproval(req._id, 'reject')}
                      className="flex-1 flex items-center justify-center space-x-1.5 bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 px-3 py-2 rounded-lg text-sm font-medium transition"
                    >
                      <XCircle className="w-4 h-4" /> <span>Reject</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
export default ApprovalQueue;
