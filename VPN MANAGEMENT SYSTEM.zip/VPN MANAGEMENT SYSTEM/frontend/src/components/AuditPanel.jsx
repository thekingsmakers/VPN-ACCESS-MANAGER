import React, { useEffect, useState } from 'react';
import { Database, Search, ShieldAlert } from 'lucide-react';

const AuditPanel = ({ api }) => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');

  const categories = ['All', 'System', 'Application', 'Security', 'SMTP', 'Logins', 'VPN Provisioning', 'Other'];

  const getCategoryColor = (cat) => {
    switch (cat) {
      case 'System': return 'bg-slate-100 text-slate-700 border-slate-200';
      case 'Application': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Security': return 'bg-red-50 text-red-700 border-red-200';
      case 'SMTP': return 'bg-indigo-50 text-indigo-700 border-indigo-200';
      case 'Logins': return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'VPN Provisioning': return 'bg-green-50 text-green-700 border-green-200';
      default: return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  useEffect(() => {
    fetchLogs();
  }, [api]);

  const fetchLogs = async () => {
    try {
      const res = await api.get('/requests/audit');
      setLogs(res.data);
    } catch(err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filtered = logs.filter(l => {
    const s = search.toLowerCase();
    const action = l.action?.toLowerCase() || '';
    const user = l.performedBy?.username?.toLowerCase() || '';
    const cat = l.category || 'Other';
    
    const matchesSearch = action.includes(s) || user.includes(s);
    const matchesCategory = categoryFilter === 'All' || cat === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });

  if (loading) return <div className="p-8 text-slate-500 font-medium">Retrieving secure system audit trails...</div>;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight flex items-center">
            <Database className="w-8 h-8 mr-3 text-slate-700" /> Audit Logs
          </h1>
          <p className="text-slate-500 mt-1">Immutable tracking matrix for all Active Directory and Request modifications.</p>
        </div>
      </div>

      <div className="glass rounded-2xl border p-6 shadow-sm overflow-hidden flex flex-col max-h-[75vh]">
        <div className="mb-6 relative">
          <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
          <input 
            type="text" 
            placeholder="Search by Administrative Action or Executing User..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-white/50 border border-slate-200 rounded-xl pl-12 pr-4 py-3 outline-none focus:ring-2 focus:ring-blue-500 shadow-sm"
          />
        </div>

        <div className="flex flex-wrap gap-2 mb-6">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold border transition duration-200 ${
                categoryFilter === cat ? 'bg-slate-800 text-white border-slate-800 shadow-md' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50 hover:border-slate-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-auto bg-white rounded-xl border border-slate-200 shadow-sm">
          {filtered.length === 0 ? (
            <div className="text-center p-12 text-slate-500 flex flex-col items-center">
              <ShieldAlert className="w-8 h-8 mb-3 text-slate-300" />
              <p>No audit signatures found matching active filters.</p>
            </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 text-xs uppercase tracking-wider font-semibold">
                  <th className="p-4 pl-6">Timestamp</th>
                  <th className="p-4">Action Signature</th>
                  <th className="p-4">Executing User</th>
                  <th className="p-4">Payload Metadata</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filtered.map(log => {
                  const catClass = getCategoryColor(log.category || 'Other');
                  return (
                  <tr key={log._id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 pl-6 text-slate-600 font-medium whitespace-nowrap">
                      {new Date(log.createdAt).toLocaleString()}
                    </td>
                    <td className="p-4">
                      <div className="flex flex-col items-start gap-1.5">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold border uppercase tracking-wider ${catClass}`}>
                          {log.category || 'Other'}
                        </span>
                        <span className="font-bold text-slate-800 text-xs">
                          {log.action}
                        </span>
                      </div>
                    </td>
                    <td className="p-4 text-slate-800 font-bold">
                      {log.performedBy?.username || 'SYSTEM'}
                    </td>
                    <td className="p-4 text-xs font-mono text-slate-500 max-w-xs truncate" title={JSON.stringify(log.metadata)}>
                      {JSON.stringify(log.metadata)}
                    </td>
                  </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuditPanel;
