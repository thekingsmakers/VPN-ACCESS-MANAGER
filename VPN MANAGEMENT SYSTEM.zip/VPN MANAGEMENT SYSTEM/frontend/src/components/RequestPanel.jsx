import React, { useEffect, useState } from 'react';
import { Send, FileText, CheckCircle2, XCircle, Clock } from 'lucide-react';

import { SettingsContext } from '../App';

const RequestPanel = ({ api, user }) => {
  const globalSettings = React.useContext(SettingsContext);
  const [requests, setRequests] = useState([]);
  const [duration, setDuration] = useState(globalSettings?.vpnDurations?.[0]?.days || 7);
  const [justification, setJustification] = useState('');
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchRequests = async () => {
    try {
      const res = await api.get('/requests/my');
      setRequests(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, [api]);

  const submitRequest = async (e) => {
    e.preventDefault();
    try {
      await api.post('/requests', { durationDays: duration, justification });
      setMsg({ text: 'Request submitted successfully!', type: 'success' });
      setJustification('');
      setDuration(7);
      fetchRequests();
    } catch (err) {
      setMsg({ text: err.response?.data?.message || 'Error submitting request', type: 'error' });
    }
  };

  const getStatusDisplay = (status) => {
    switch (status) {
      case 'approved': return <span className="bg-green-100 text-green-700 font-semibold px-2.5 py-1 rounded-md text-xs flex w-fit items-center"><CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Fully Approved</span>;
      case 'rejected': return <span className="bg-red-100 text-red-700 font-semibold px-2.5 py-1 rounded-md text-xs flex w-fit items-center"><XCircle className="w-3.5 h-3.5 mr-1" /> Rejected</span>;
      case 'pending_manager': return <span className="bg-amber-100 text-amber-700 font-semibold px-2.5 py-1 rounded-md text-xs flex w-fit items-center"><Clock className="w-3.5 h-3.5 mr-1" /> Pending Manager</span>;
      case 'pending_security': return <span className="bg-indigo-100 text-indigo-700 font-semibold px-2.5 py-1 rounded-md text-xs flex w-fit items-center"><Clock className="w-3.5 h-3.5 mr-1" /> Pending Security Team</span>;
      case 'pending_it': return <span className="bg-blue-100 text-blue-700 font-semibold px-2.5 py-1 rounded-md text-xs flex w-fit items-center"><Clock className="w-3.5 h-3.5 mr-1" /> Pending IT Admin</span>;
      default: return <span className="bg-slate-100 text-slate-700 font-semibold px-2.5 py-1 rounded-md text-xs flex w-fit items-center"><Clock className="w-3.5 h-3.5 mr-1" /> Processing...</span>;
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">VPN Requests</h1>
        <p className="text-slate-500 mt-1">Submit new access requests and view your history.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Form Column */}
        <div className="lg:col-span-1">
          <div className="glass p-6 rounded-2xl border shadow-sm sticky top-8">
            <div className="flex items-center space-x-2 text-indigo-600 mb-6">
              <Send className="w-5 h-5" />
              <h2 className="text-lg font-bold">New Request</h2>
            </div>

            {msg && (
              <div className={`p-3 rounded-xl mb-6 text-sm flex justify-between ${msg.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
                <span>{msg.text}</span>
                <button onClick={() => setMsg(null)} className="font-bold opacity-70 hover:opacity-100">×</button>
              </div>
            )}

            {(globalSettings?.workflow?.disableUserRequests && user?.role === 'user') ? (
              <div className="p-6 text-center text-slate-500 bg-white/50 rounded-xl border border-dashed border-slate-300">
                Self-service requests are currently disabled natively by IT Administration. All provisions are managed centrally via bulk drops.
              </div>
            ) : (
              <form onSubmit={submitRequest} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Duration</label>
                  <select 
                    className="w-full border-slate-200 bg-white/50 px-3 py-2.5 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
                    value={duration}
                    onChange={(e) => setDuration(Number(e.target.value))}
                  >
                    {globalSettings?.vpnDurations?.map(dur => (
                      <option key={dur.days} value={dur.days}>{dur.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Justification</label>
                  <textarea 
                    required
                    className="w-full border-slate-200 bg-white/50 px-3 py-2.5 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 h-28 resize-none shadow-sm"
                    placeholder="Elaborate on why you need access..."
                    value={justification}
                    onChange={(e) => setJustification(e.target.value)}
                  />
                </div>
                <button type="submit" className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-medium shadow-md shadow-indigo-500/30 transition-colors">
                  Submit Application
                </button>
              </form>
            )}
          </div>
        </div>

        {/* History Column */}
        <div className="lg:col-span-2">
          <div className="glass rounded-2xl border shadow-sm overflow-hidden flex flex-col h-full min-h-[400px]">
            <div className="p-6 border-b border-white/50 bg-white/30 backdrop-blur-md">
              <div className="flex items-center space-x-2 text-slate-800">
                <FileText className="w-5 h-5 text-slate-500" />
                <h2 className="text-lg font-bold">Request History</h2>
              </div>
            </div>
            
            <div className="p-0 flex-1 bg-white/20">
              {loading ? (
                <div className="text-center p-8 text-slate-500">Loading history...</div>
              ) : requests.length === 0 ? (
                <div className="text-center p-12 text-slate-500">
                  You haven't made any requests yet.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="bg-slate-50/50 text-slate-500 border-b">
                        <th className="py-4 px-6 font-semibold w-32">Date</th>
                        <th className="py-4 px-6 font-semibold w-24">Duration</th>
                        <th className="py-4 px-6 font-semibold flex-1">Context / Justification</th>
                        <th className="py-4 px-6 font-semibold w-36">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {requests.map(req => (
                        <tr key={req._id} className="border-b last:border-0 border-slate-100 hover:bg-white/40 transition text-slate-700">
                          <td className="py-4 px-6 whitespace-nowrap">{new Date(req.createdAt).toLocaleDateString()}</td>
                          <td className="py-4 px-6 font-medium text-slate-900">{req.durationDays}d</td>
                          <td className="py-4 px-6 text-slate-500 truncate max-w-[200px]">{req.justification}</td>
                          <td className="py-4 px-6">
                            {getStatusDisplay(req.status)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default RequestPanel;
