import React, { useState } from 'react';
import axios from 'axios';
import { Database, Shield, Server, ShieldCheck, Mail, ArrowRight, User } from 'lucide-react';

const SetupHub = ({ isMongoConnected }) => {
  const [step, setStep] = useState(isMongoConnected ? 1 : 0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    mongoIp: '127.0.0.1',
    mongoPort: 27017,
    mongoUser: '',
    mongoPass: '',
    mongoDb: 'vpn_management',
    adDomain: 'domain.local',
    adUsername: 'admin',
    adPassword: '',
    adminUsername: 'jdoe',
    adminEmail: 'jdoe@domain.com',
    smtpHost: 'smtp.office365.com',
    smtpPort: 587,
    smtpUser: '',
    smtpPass: ''
  });

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleMongoBind = async () => {
    setLoading(true);
    setError('');
    try {
      const authClause = (formData.mongoUser && formData.mongoPass) ? `${encodeURIComponent(formData.mongoUser)}:${encodeURIComponent(formData.mongoPass)}@` : '';
      const constructedUri = `mongodb://${authClause}${formData.mongoIp}:${formData.mongoPort}/${formData.mongoDb}?authSource=admin`;
      
      const dbResponse = await axios.post('/api/setup/database', { mongoUri: constructedUri });
      
      if (dbResponse.data.isAlreadySetup) {
        alert('Existing Enterprise Array detected! Skipping Setup Hub entirely...');
        window.location.href = '/login';
      } else {
        alert('Hardware Topology mapped successfully! System may briefly pause on next step while services restart.');
        setStep(1);
      }
    } catch(err) {
      setError(err.response?.data?.message || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleInit = async () => {
    setLoading(true);
    setError('');
    try {
      const constructedAdUrl = `ldap://${formData.adDomain}`;
      const constructedBaseDn = `DC=${formData.adDomain.split('.').join(',DC=')}`;
      const constructedAdUser = formData.adUsername.includes('@') ? formData.adUsername : `${formData.adUsername}@${formData.adDomain}`;

      const payload = {
        ad: { url: constructedAdUrl, baseDn: constructedBaseDn, username: constructedAdUser, password: formData.adPassword },
        admin: { username: formData.adminUsername, email: formData.adminEmail },
        smtp: { host: formData.smtpHost, port: formData.smtpPort, user: formData.smtpUser, pass: formData.smtpPass, secure: false }
      };
      await axios.post('/api/setup/initialize', payload);
      alert('Enterprise Configuration Verified! Rebooting local bounds...');
      window.location.href = '/login';
    } catch(err) {
      setError(err.response?.data?.message || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6 text-slate-200">
      <div className="w-full max-w-4xl bg-slate-800 rounded-3xl overflow-hidden shadow-2xl flex border border-slate-700">
        
        {/* Sidebar Status */}
        <div className="w-1/3 bg-slate-850 p-8 border-r border-slate-700 hidden md:block relative overflow-hidden bg-slate-900">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-indigo-500"></div>
          <Shield className="w-12 h-12 text-blue-500 mb-6" />
          <h2 className="text-2xl font-bold text-white mb-2 tracking-tight">Enterprise Onboarding Matrix</h2>
          <p className="text-sm text-slate-400 mb-8">Establish zero-trust endpoints physically connecting native arrays securely.</p>
          
          <div className="space-y-6">
            {!isMongoConnected && (
              <div className={`flex items-center space-x-4 ${step === 0 ? 'text-blue-400' : 'text-slate-500'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${step === 0 ? 'border-blue-400' : 'border-slate-500'}`}>0</div>
                <span className="font-semibold text-sm">Database Topology</span>
              </div>
            )}
            <div className={`flex items-center space-x-4 ${step === 1 ? 'text-indigo-400' : 'text-slate-500'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${step === 1 ? 'border-indigo-400' : 'border-slate-500'}`}>1</div>
              <span className="font-semibold text-sm">Active Directory</span>
            </div>
            <div className={`flex items-center space-x-4 ${step === 2 ? 'text-emerald-400' : 'text-slate-500'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${step === 2 ? 'border-emerald-400' : 'border-slate-500'}`}>2</div>
              <span className="font-semibold text-sm">Super Admin Identity</span>
            </div>
            <div className={`flex items-center space-x-4 ${step === 3 ? 'text-amber-400' : 'text-slate-500'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${step === 3 ? 'border-amber-400' : 'border-slate-500'}`}>3</div>
              <span className="font-semibold text-sm">SMTP Relay Bounds</span>
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="w-full md:w-2/3 p-10 animate-in fade-in zoom-in-95 duration-500 flex flex-col justify-between min-h-[500px]">
          
          {step === 0 && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white flex items-center">
                <Database className="w-6 h-6 mr-3 text-blue-500"/> Connect Database Topology
              </h3>
              <p className="text-sm text-slate-400 mb-8">Establish physical bare-metal bindings mapped to MongoDB structure.</p>
              
              {error && <div className="bg-red-500/10 border border-red-500/50 text-red-500 p-4 rounded-xl text-sm font-semibold">{error}</div>}

              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="col-span-2">
                    <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Server IP / Hostname</label>
                    <input type="text" name="mongoIp" value={formData.mongoIp} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-mono text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Port</label>
                    <input type="number" name="mongoPort" value={formData.mongoPort} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-mono text-sm" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Database Name</label>
                  <input type="text" name="mongoDb" value={formData.mongoDb} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-mono text-sm" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Username (Optional)</label>
                    <input type="text" name="mongoUser" value={formData.mongoUser} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-mono text-sm" placeholder="Leave empty if unused" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Password (Optional)</label>
                    <input type="password" name="mongoPass" value={formData.mongoPass} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-mono text-sm" />
                  </div>
                </div>
              </div>
              <button disabled={!formData.mongoIp || !formData.mongoDb || loading} onClick={handleMongoBind} className="mt-8 ml-auto flex items-center bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-blue-500/20 font-bold">
                {loading ? 'Initializing Array...' : 'Bind Configuration & Reboot'} <ArrowRight className="w-5 h-5 ml-2" />
              </button>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white flex items-center">
                <Database className="w-6 h-6 mr-3 text-blue-500"/> Connect LDAP Array
              </h3>
              <p className="text-sm text-slate-400 mb-8">Establish connection mapping strictly to the domain controller.</p>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Domain Root (e.g. tkm.local)</label>
                  <input type="text" name="adDomain" value={formData.adDomain} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-mono text-sm" placeholder="company.local" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Bind Username</label>
                    <input type="text" name="adUsername" value={formData.adUsername} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-mono text-sm" placeholder="admin" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Bind Password</label>
                    <input type="password" name="adPassword" value={formData.adPassword} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-mono text-sm" />
                  </div>
                </div>
              </div>
              <button disabled={!formData.adDomain || !formData.adUsername || !formData.adPassword} onClick={() => setStep(2)} className="mt-8 ml-auto flex items-center bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-blue-500/20 font-bold">
                Map Identity <ArrowRight className="w-5 h-5 ml-2" />
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white flex items-center">
                <User className="w-6 h-6 mr-3 text-indigo-500"/> Skeleton Administrator
              </h3>
              <p className="text-sm text-slate-400 mb-8">This Active Directory target account will automatically be granted un-revocable globally immune `super_admin` permissions.</p>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Exact AD sAMAccountName</label>
                  <input type="text" name="adminUsername" value={formData.adminUsername} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-mono text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Exact Email Array</label>
                  <input type="email" name="adminEmail" value={formData.adminEmail} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-mono text-sm" />
                </div>
              </div>
              <div className="flex justify-between mt-8">
                <button disabled={!isMongoConnected && step === 1} onClick={() => setStep(step - 1)} className={`flex items-center transition-colors ${!isMongoConnected && step === 1 ? 'opacity-0 cursor-default' : 'text-slate-400 hover:text-white'}`}>Go Back</button>
                <button disabled={!formData.adminUsername || !formData.adminEmail} onClick={() => setStep(3)} className="flex items-center bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3 rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-indigo-500/20 font-bold">
                  SMTP Integration <ArrowRight className="w-5 h-5 ml-2" />
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white flex items-center">
                <Mail className="w-6 h-6 mr-3 text-emerald-500"/> Connect SMTP Array
              </h3>
              <p className="text-sm text-slate-400 mb-8">Execute notification payloads efficiently mappings towards mailers.</p>
              
              {error && <div className="bg-red-500/10 border border-red-500/50 text-red-500 p-4 rounded-xl text-sm font-semibold">{error}</div>}

              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="col-span-2">
                    <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Host String</label>
                    <input type="text" name="smtpHost" value={formData.smtpHost} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-mono text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Port</label>
                    <input type="number" name="smtpPort" value={formData.smtpPort} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-mono text-sm" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Authentication User</label>
                    <input type="text" name="smtpUser" value={formData.smtpUser} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-mono text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Authentication Password</label>
                    <input type="password" name="smtpPass" value={formData.smtpPass} onChange={handleChange} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-mono text-sm" />
                  </div>
                </div>
              </div>

              <div className="flex justify-between mt-8">
                <button onClick={() => setStep(2)} className="flex items-center text-slate-400 hover:text-white transition-colors" disabled={loading}>Go Back</button>
                <button disabled={loading} onClick={handleInit} className="flex items-center bg-emerald-600 hover:bg-emerald-500 text-white px-8 py-3 rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-emerald-500/20 font-bold">
                  <ShieldCheck className="w-5 h-5 mr-2" />
                  {loading ? 'Executing Hardware Mapping...' : 'Finalize & Boot Architecture'}
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default SetupHub;
