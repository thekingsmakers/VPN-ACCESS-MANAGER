import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Layout from './Layout';
import OverviewPanel from './OverviewPanel';
import AccessPanel from './AccessPanel';
import RequestPanel from './RequestPanel';
import ApprovalQueue from './ApprovalQueue';
import SettingsPanel from './SettingsPanel';
import AuditPanel from './AuditPanel';
import ProvisionPanel from './ProvisionPanel';
import ReportsPanel from './ReportsPanel';

const api = axios.create({
  baseURL: '/api',
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

const Dashboard = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
    } else {
      navigate('/login');
    }
  }, [navigate]);

  if (!user) return null;

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewPanel api={api} user={user} setActiveTab={setActiveTab} />;
      case 'access':
        return <AccessPanel api={api} />;
      case 'requests':
        return <RequestPanel api={api} user={user} />;
      case 'approvals':
        return <ApprovalQueue api={api} user={user} />;
      case 'settings':
        return <SettingsPanel api={api} />;
      case 'audit':
        return <AuditPanel api={api} />;
      case 'provisioning':
        return <ProvisionPanel api={api} />;
      case 'reports':
        return <ReportsPanel api={api} />;
      default:
        return <OverviewPanel api={api} user={user} setActiveTab={setActiveTab} />;
    }
  };

  return (
    <Layout user={user} activeTab={activeTab} setActiveTab={setActiveTab}>
      {renderContent()}
    </Layout>
  );
};

export default Dashboard;
