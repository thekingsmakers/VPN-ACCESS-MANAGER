import React, { useEffect, useState } from 'react';
import { BarChart3, Download, FileJson, FileSpreadsheet, FileText, Search, TrendingUp, Users, Calendar } from 'lucide-react';

const ReportsPanel = ({ api }) => {
  const [data, setData] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    search: ''
  });

  useEffect(() => {
    fetchStats();
    fetchDetailedReport();
  }, [api]);

  const fetchStats = async () => {
    try {
      const res = await api.get('/reports/stats');
      setStats(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchDetailedReport = async () => {
    setLoading(true);
    try {
      const res = await api.get('/reports/detailed', { params: filters });
      setData(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const applyFilters = () => {
    fetchDetailedReport();
  };

  const exportCSV = () => {
    const headers = ['Start Date', 'End Date', 'User', 'Full Name', 'Email', 'Duration', 'Grantor', 'Justification'];
    const rows = data.map(r => [
      new Date(r.startDate).toLocaleString(),
      new Date(r.endDate).toLocaleString(),
      r.userId?.username,
      r.userId?.fullName || 'N/A',
      r.userId?.email,
      `${((new Date(r.endDate) - new Date(r.startDate)) / (1000 * 60 * 60 * 24)).toFixed(2)} days`,
      r.requestId?.itAdminId?.username || 'SYSTEM',
      r.requestId?.justification || ''
    ]);

    let csvContent = "data:text/csv;charset=utf-8," + headers.join(",") + "\n" + rows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `vpn_report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
  };

  const exportExcel = () => {
    if (!window.XLSX) return alert("Excel library loading...");
    const worksheet = window.XLSX.utils.json_to_sheet(data.map(r => ({
      'Start Date': new Date(r.startDate).toLocaleString(),
      'End Date': new Date(r.endDate).toLocaleString(),
      'Username': r.userId?.username,
      'Full Name': r.userId?.fullName || 'N/A',
      'Email': r.userId?.email,
      'Duration (Days)': ((new Date(r.endDate) - new Date(r.startDate)) / (1000 * 60 * 60 * 24)).toFixed(2),
      'Grantor': r.requestId?.itAdminId?.username || 'SYSTEM',
      'Justification': r.requestId?.justification || ''
    })));
    const workbook = window.XLSX.utils.book_new();
    window.XLSX.utils.book_append_sheet(workbook, worksheet, "VPN Report");
    window.XLSX.writeFile(workbook, `vpn_report_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const exportPDF = () => {
    if (!window.jspdf) return alert("PDF library loading...");
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('l', 'mm', 'a4');
    
    doc.setFontSize(18);
    doc.text("VPN Access Audit Report", 14, 22);
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`Generated on: ${new Date().toLocaleString()}`, 14, 28);

    const tableHeaders = [['User', 'Full Name', 'Start Date', 'End Date', 'Dur (d)', 'Grantor']];
    const tableData = data.map(r => [
      r.userId?.username,
      r.userId?.fullName || 'N/A',
      new Date(r.startDate).toLocaleDateString(),
      new Date(r.endDate).toLocaleDateString(),
      ((new Date(r.endDate) - new Date(r.startDate)) / (1000 * 60 * 60 * 24)).toFixed(1),
      r.requestId?.itAdminId?.username || 'SYS'
    ]);

    doc.autoTable({
      startY: 35,
      head: tableHeaders,
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [79, 70, 229] },
      styles: { fontSize: 8 }
    });

    doc.save(`vpn_report_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight flex items-center">
            <BarChart3 className="w-8 h-8 mr-3 text-indigo-600" /> Advanced Analytics
          </h1>
          <p className="text-slate-500 mt-1">Cross-referencing Active Directory events with local provisioning audit trails.</p>
        </div>
        <div className="flex space-x-3">
           <button onClick={exportCSV} className="flex items-center space-x-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-xl text-sm font-medium transition shadow-sm">
             <FileJson className="w-4 h-4" /> <span>CSV</span>
           </button>
           <button onClick={exportExcel} className="flex items-center space-x-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-xl text-sm font-medium transition shadow-sm">
             <FileSpreadsheet className="w-4 h-4 text-green-600" /> <span>Excel</span>
           </button>
           <button onClick={exportPDF} className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition shadow-md shadow-indigo-200">
             <FileText className="w-4 h-4" /> <span>PDF Report</span>
           </button>
        </div>
      </div>

      {/* Stats Widgets */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard icon={Users} label="Total Users Synced" value={stats?.totalUsers || 0} color="indigo" />
        <StatCard icon={TrendingUp} label="Total Provisions" value={stats?.totalRequests || 0} color="blue" />
        <StatCard icon={Calendar} label="Active Tunnels" value={stats?.totalActive || 0} color="green" />
        <div className="glass p-5 rounded-2xl border shadow-sm">
           <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Top Requesters</h4>
           <div className="space-y-2">
             {stats?.topUsers?.map((u, i) => (
               <div key={i} className="flex justify-between items-center text-xs">
                 <span className="text-slate-700 font-medium">{u.username}</span>
                 <span className="bg-slate-100 px-2 py-0.5 rounded-full font-bold">{u.count}</span>
               </div>
             ))}
           </div>
        </div>
      </div>

      {/* Filters */}
      <div className="glass p-6 rounded-2xl border shadow-sm flex flex-col md:flex-row items-end gap-4">
        <div className="flex-1 space-y-1.5">
          <label className="text-xs font-bold text-slate-500 uppercase ml-1">Search User / Grantor</label>
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              name="search"
              type="text" 
              placeholder="Username, Name, Email..." 
              value={filters.search}
              onChange={handleFilterChange}
              className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500 transition"
            />
          </div>
        </div>
        <div className="w-full md:w-44 space-y-1.5">
          <label className="text-xs font-bold text-slate-500 uppercase ml-1">Start Date</label>
          <input 
            name="startDate"
            type="date" 
            value={filters.startDate}
            onChange={handleFilterChange}
            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500 transition"
          />
        </div>
        <div className="w-full md:w-44 space-y-1.5">
          <label className="text-xs font-bold text-slate-500 uppercase ml-1">End Date</label>
          <input 
            name="endDate"
            type="date" 
            value={filters.endDate}
            onChange={handleFilterChange}
            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500 transition"
          />
        </div>
        <button 
          onClick={applyFilters}
          className="bg-slate-800 hover:bg-black text-white px-6 py-2 rounded-xl text-sm font-bold transition h-[38px]"
        >
          Apply Filters
        </button>
      </div>

      {/* Main Table */}
      <div className="glass rounded-2xl border shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50/50 text-slate-500 border-b border-slate-200 uppercase text-[10px] font-bold tracking-widest">
                <th className="py-4 px-6">User / Identity</th>
                <th className="py-4 px-6">Approval Signature</th>
                <th className="py-4 px-6">Duration Range</th>
                <th className="py-4 px-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white/30 backdrop-blur-sm">
              {loading ? (
                <tr><td colSpan="4" className="py-12 text-center text-slate-400">Querying identity records...</td></tr>
              ) : data.length === 0 ? (
                <tr><td colSpan="4" className="py-12 text-center text-slate-400">No records found for the selected criteria.</td></tr>
              ) : (
                data.map(r => (
                  <tr key={r._id} className="hover:bg-indigo-50/30 transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex flex-col">
                        <span className="font-bold text-slate-900">{r.userId?.fullName || r.userId?.username}</span>
                        <span className="text-xs text-slate-500">{r.userId?.email}</span>
                        <span className="text-[10px] text-indigo-500 font-mono mt-0.5 uppercase tracking-tighter">{r.userId?.username}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                       <div className="flex flex-col space-y-1">
                          <span className="text-xs font-semibold text-slate-700 block">Grantor: <span className="text-indigo-600">{r.requestId?.itAdminId?.username || 'SYSTEM'}</span></span>
                          <span className="text-[10px] text-slate-400 italic font-medium line-clamp-1">"{r.requestId?.justification || 'Initial auto-provision'}"</span>
                       </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex flex-col">
                         <span className="text-xs font-bold text-slate-800">{new Date(r.startDate).toLocaleDateString()} — {new Date(r.endDate).toLocaleDateString()}</span>
                         <span className="text-[10px] text-slate-500">{((new Date(r.endDate) - new Date(r.startDate)) / (1000 * 60 * 60 * 24)).toFixed(1)} days extension</span>
                      </div>
                    </td>
                    <td className="py-4 px-6 text-right">
                       <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${r.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>
                         {r.status}
                       </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ icon: Icon, label, value, color }) => (
  <div className="glass p-5 rounded-2xl border shadow-sm group hover:border-indigo-200 transition-colors">
    <div className={`w-10 h-10 rounded-xl mb-4 flex items-center justify-center bg-${color}-50 text-${color}-600 group-hover:scale-110 transition-transform`}>
      <Icon className="w-5 h-5" />
    </div>
    <div className="text-2xl font-black text-slate-900">{value}</div>
    <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">{label}</div>
  </div>
);

export default ReportsPanel;
