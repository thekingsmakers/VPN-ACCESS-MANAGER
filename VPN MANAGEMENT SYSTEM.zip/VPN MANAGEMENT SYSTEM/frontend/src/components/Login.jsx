import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Lock } from 'lucide-react';
import { SettingsContext } from '../App';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const globalSettings = useContext(SettingsContext);
  
  const portalName = globalSettings?.branding?.portalName || 'VPN Access Portal';

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      // Point to backend relatively via proxy
      const res = await axios.post('/api/auth/login', { username, password });
      localStorage.setItem('token', res.data.token);
      localStorage.setItem('user', JSON.stringify(res.data));
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed');
    }
  };

  const bgImg = globalSettings?.branding?.loginBackgroundBase64 || globalSettings?.branding?.loginBackgroundUrl;

  return (
    <div 
      className="flex items-center justify-center min-h-screen bg-slate-100 relative bg-cover bg-center"
      style={bgImg ? { backgroundImage: `url(${bgImg})` } : {}}
    >
      {bgImg && <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm z-0"></div>}
      
      <div className="bg-white/95 backdrop-blur-md p-8 rounded-2xl shadow-2xl w-full max-w-md border border-slate-200/50 z-10 relative">
        <div className="flex justify-center mb-6">
          {globalSettings?.branding?.logoBase64 || globalSettings?.branding?.logoUrl ? (
            <img src={globalSettings.branding.logoBase64 || globalSettings.branding.logoUrl} alt="System Logo" className="h-16 w-auto object-contain drop-shadow-sm" />
          ) : (
            <div className="bg-blue-600 p-3 rounded-full text-white">
              <Lock className="w-8 h-8" />
            </div>
          )}
        </div>
        <h2 className="text-2xl font-bold text-center text-slate-800 mb-2">{portalName}</h2>
        <p className="text-center text-slate-500 mb-8">Sign in with your Active Directory credentials</p>
        
        {error && <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4 text-sm">{error}</div>}
        
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
            <input 
              type="text" 
              required
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="e.g. jdoe@domain.com"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
            <input 
              type="password" 
              required
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button 
            type="submit"
            className="w-full bg-blue-600 text-white font-medium py-2 px-4 rounded-lg hover:bg-blue-700 transition"
          >
            Sign In
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
